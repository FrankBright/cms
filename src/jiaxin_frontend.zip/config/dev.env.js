module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  BASE_API: '"/"',
  // IMG_UPLOAD_URL: '"/mwallet_api/giftcardActivity/upload"',
  // LOGIN_OUT_URL: '"/#/login"'
}
