<template>
   <div class="thedetail">
       <!-- 过滤表单 start-->
       <XFilterComponent @submit="filterQuery" :formData="filterData" :rules="rules" :hideHeight="58*2">
            <!-- 下单时间 -->
           <el-form-item label="下单时间" prop="expectOrderDate" style="width:50%">
               <el-date-picker
                v-model='filterData.requestTime'
                v-start='start'
                type="datetimerange"
                range-separator="至"
                :default-time="['00:00:00', '23:59:59']"
                value-format="yyyy-MM-dd HH:mm:ss"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
              </el-date-picker>
           </el-form-item>
            <!-- 到账时间 -->
           <el-form-item label="到账时间" prop="requestTime" style="width:50%">
               <el-date-picker
                v-model="filterData.requestTime"
                type="daterange"
                range-separator="至"
                value-format="yyyy-MM-dd HH:mm:ss"
                :default-time="['00:00:00', '23:59:59']"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
              </el-date-picker>
           </el-form-item>
           <!-- 交易类型 -->
           <XSelectCompoent label="交易类型" :clearable="true" name="transType" :optionsData="transTypeAry" v-model="filterData.transType"></XSelectCompoent>
            <!-- 付款方账户号 -->
           <el-form-item label="付款方账户号" prop="payerAccNo">
               <el-input v-model="filterData.payerAccNo" placeholder="付款方账户号"></el-input>
           </el-form-item>
            <!-- 收款方账户号 -->
           <el-form-item label="收款方账户号" prop="payeeAccNo">
               <el-input v-model="filterData.payeeAccNo" placeholder="付款方账户号"></el-input>
           </el-form-item>
            <!-- 订单号 -->
           <el-form-item label="订单号" prop="tradeId">
               <el-input v-model="filterData.tradeId" placeholder="订单号"></el-input>
           </el-form-item>
            <!-- 付款方账户名 -->
           <el-form-item label="付款方账户名" prop="payerAccName">
               <el-input v-model="filterData.payerAccName" placeholder="付款方账户名"></el-input>
           </el-form-item>
            <!-- 收款方账户号 -->
           <el-form-item label="收款方账户名" prop="payeeAccName">
               <el-input v-model="filterData.payeeAccName" placeholder="收款方账户名"></el-input>
           </el-form-item>
            <!-- 交易状态 -->
           <XSelectCompoent label="交易状态" :clearable="true" name="transStatus" :optionsData="transStatusAry" v-model="filterData.transStatus"></XSelectCompoent>
            <!-- 付款方币种 -->
           <el-form-item label="付款方币种" prop="payerCnyShortName">
               <el-input v-model="filterData.payerCnyShortName" placeholder="付款方币种"></el-input>
           </el-form-item>
            <!-- 收款方币种 -->
           <el-form-item label="收款方币种" prop="payeeCnyShortName">
               <el-input v-model="filterData.payeeCnyShortName" placeholder="收款方币种"></el-input>
           </el-form-item>
           
           
           <!-- <el-form-item label="活动名称" prop="tiping">
                <el-select v-model="filterData.tiping" placeholder="请选择">
                    <el-option
                    v-for="item in tipingOption"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
           </el-form-item> -->
           <!-- <XSelectCompoent url="/report-manager/permission/mhtManagerByDeptId.do" label="商务经理" name="managerId" v-model="queryData.managerId" ></XSelectCompoent> -->
       </XFilterComponent>
       <!-- 过滤表单 end-->
       <!-- 表格 start-->
       <XTableComponent ref='tableList' :url="queryListUrl" :filterData="filterData">
            <template slot="table">
                <el-table-column prop="tradeId" label="订单号"></el-table-column>
                <el-table-column prop="payerAccNo" label="付款方账户号"></el-table-column>
                <el-table-column prop="payerAccName" label="付款方账户名称"></el-table-column>
                <el-table-column prop="payerCnyShortName" label="付款方币种"></el-table-column>
                <el-table-column label="付款方金额" >
                    <template slot-scope="scope">
                        {{scope.row.payerAmount}}
                    </template>
                </el-table-column>
                <el-table-column prop="payeeAccNo" label="收款方账户号"></el-table-column>
                <el-table-column prop="payeeAccName" label="收款方账户名"></el-table-column>
                <el-table-column prop="payeeCnyShortName" label="收款方币种"></el-table-column>
                <el-table-column label="收款方金额" >
                    <template slot-scope="scope">
                        {{scope.row.payeeAmount}}
                    </template>
                </el-table-column>
                <el-table-column label="交易类型">
                    <template slot-scope="scope">
                        {{transTypeAry[scope.row.transType].label}}
                    </template>
                </el-table-column>
                <el-table-column label="交易状态">
                    <template slot-scope="scope">
                        {{transStatusAry[scope.row.transStatus].label}}
                    </template>
                </el-table-column>
                <el-table-column label="下单时间">
                    <template slot-scope="scope">
                        {{scope.row.requestTime}}
                    </template>
                </el-table-column>
                <el-table-column label="到账时间">
                    <template slot-scope="scope">
                        {{scope.row.requestTime}}
                    </template>
                </el-table-column>
                <el-table-column label="操作" fixed="right">
                    <template slot-scope="scope">
                        <el-button size="text" @click="viewDetail(scope.row)"> <i class="iconfont icon-chakan"></i> 查看</el-button>
                    </template>
                </el-table-column>
            </template>
       </XTableComponent>
        <!-- 表格 end-->

        <!-- 弹窗详情 -->
        <el-dialog
          title="详情"
          :visible.sync="dialogVisible"
          width="60%">
          <table cellspacing="0" cellpadding="0" class="lodingTable" v-if="detailData">
              <tr v-for="n in Object.keys(detailConfig).length/2" :key="n">
                  <!-- <td>{{n}}</td> -->
                  <td class="th">{{detailConfig[Object.keys(detailConfig)[2*n-2]]}}</td>
                  <td>{{detailData[Object.keys(detailConfig)[2*n-2]]||'--'}}</td>
                  <td class="th">{{detailConfig[Object.keys(detailConfig)[2*n-1]]}}</td>
                  <td>{{detailData[Object.keys(detailConfig)[2*n-1]]||'--'}}</td>
              </tr>
          </table>
          <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">关闭</el-button>
          </span>
        </el-dialog>
   </div>
</template>

<script>
import optionConfig from "./optionConfig";
import XFilterComponent from "@/components/FilterTable/XFilterComponent";
import XTableComponent from "@/components/FilterTable/XTableComponent";
import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
export default {
  name: "example",
  components: {
    XFilterComponent, //过滤表单组件
    XTableComponent, //表格组件
    XSelectCompoent //下拉二次封装
  },
  data() {
    return {
      start: '222',
      end: '',
      ...optionConfig,
      detailData: null,
      dialogVisible: false,
      //-----------------列表查询模型必要配置start
      filterData: {
        //过滤条件数据，所有查询字段需实现定义
        expectOrderDate: [], //时间范围默认是前端控件是数组类型，不符合接口类型，需进行watch进行分别赋值，建议后端更改接口类型最为合适
        expectOrderDateStart: null,
        expectOrderDateEnd: null,
        requestTime: [], //同上watch
        requestTimeStart: null,
        requestTimeEnd: null,
        transType: null,
        payerAccNo: null,
        payeeAccNo: null,
        tradeId: null,
        payerAccName: null,
        payeeAccName: null,
        transStatus: null,
        payerCnyShortName: null,
        payeeCnyShortName: null
      },
      rules: {
        //过滤提交校验、非必填:样例如下
        // userName: [
        //   { required: true, message: "请输入用户名", trigger: "blur" },
        //   { min: 1, max: 7, message: "长度在 1 到 7 个字符", trigger: "blur" }
        // ]
      },
      queryListUrl: "/inter_manage/manage/query/queryTradeInfo", //列表查询url
      // formatFilterData:null, 过滤数据不能直接使用，启用该方式
      //-----------------列表查询模型必要配置end

      detailConfig: {
        tradeId: "订单号",
        transType: "交易类型",
        payerAccName: "付款方账户名称",
        payerAccNo: "付款方账户号",
        payerDcType: "付款方借贷类型",
        payerAccType: "付款方账户类型",
        payerAmount: "付款方金额",
        payerCurrencyCode: "付款方币种",
        payeeAccNo: "收款方账户号",
        payeeAccName: "收款方账户名称",
        payeeCurrencyCode: "收款方币种",
        payeeAmount: "收款方金额",
        payeeDcType: "收款方借贷类型",
        payeeAccType: "收款方账户类型",
        requestTime: "下单时间",
        expectOrderDate: "预期交易时间",
        payTime: "到账时间",
        transStatus: "交易状态",
        memo: "交易备注",
        errorMsg: "失败原因"
      }
    };
  },
  created() {},
  mounted() {},
  updated(){
  },
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    viewDetail(row) {
      this.detailData = row;
      this.dialogVisible = true;
    }
  },
  watch: {
    "filterData.requestTime"(val, oldVal) {
      if (val && val.length > 0) {
        this.filterData.requestTimeStart = val[0];
        this.filterData.requestTimeEnd = val[1];
      } else {
        this.filterData.requestTimeStart = null;
        this.filterData.requestTimeEnd = null;
      }
    },
    "filterData.expectOrderDate"(val, oldVal) {
      if (val && val.length > 0) {
        this.filterData.expectOrderDateStart = val[0];
        this.filterData.expectOrderDateEnd = val[1];
      } else {
        this.filterData.expectOrderDateStart = null;
        this.filterData.expectOrderDateEnd = null;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.lodingTable {
  border-spacing: 0;
  border-collapse: collapse;
  width: 100%;
  line-height: 20px;
  tr {
    td {
      text-align: center;
      border: 1px solid #e1e1e1;
      padding: 10px;
    }
    .th {
      border: 1px solid #e1e1e1;
      width: 140px;
      font-weight: 700;
      padding: 10px;
    }
  }
}
</style>