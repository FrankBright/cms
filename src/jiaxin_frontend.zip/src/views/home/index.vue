<template>
  <div class="home">
    <div class="account">
      <dl class="total">
        <dt></dt>
        <dd class="mgt-10">账户总金额</dd>
        <dd class="money">￥{{balance.toFixed(2)}}</dd>
      </dl>
      <div class="month">
        <div class="hd">本月完成打款</div>
        <div class="bd">
          <dl>
            <dt>完成打款笔数</dt>
            <dd>
              {{transCount}}
              <span>笔</span>
            </dd>
          </dl>
          <dl>
            <dt>完成打款金额</dt>
            <dd>
              {{transAmount.toFixed(2)}}
              <span>元</span>
            </dd>
          </dl>
        </div>
      </div>
    </div>
    <div class="info">
      <div class="record">
        <div class="hd">
          <!-- <a href="http://">查看更多</a> -->
          近期交易明细
        </div>
        <div class="bd">
          <!-- 表格 start-->
          <XTableComponent
            ref="tableList"
            :url="queryListUrl"
            :filterData="filterData"
            height="320"
          >
            <template slot="table">
              <el-table-column prop="transDate" label="交易时间"></el-table-column>
              <el-table-column prop="transType.desc" label="交易类型"></el-table-column>
              <el-table-column prop="amount" label="金额(元)"></el-table-column>
              <!-- <el-table-column prop="paidAmount" label="出账"></el-table-column> -->
              <el-table-column prop="status" label="状态">
                <template slot-scope="scope">
                  成功
                </template>

              </el-table-column>
              <!-- <el-table-column label="付款方金额">
                <template slot-scope="scope">{{scope.row.payerAmount}}</template>
              </el-table-column>-->
            </template>
          </XTableComponent>
          <!-- 表格 end-->
        </div>
      </div>
      <div class="rct">
        <div v-for="(item,i) in linkConfig" :key="i" @click="linkTo(item.url)">
          <img :src="item.imgUrl">
          {{item.title}}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import echarts from "echarts";
import { mapGetters } from "vuex";
import XTableComponent from "@/components/FilterTable/XTableComponent";
export default {
  name: "mainPage",
  components: {
    XTableComponent
  },
  data() {
    return {
      balance:0,
      transCount:0,
      transAmount:0,
      linkConfig: [
        {
          url: "/account/funds",
          imgUrl: require("@/assets/images/cz-icon.png"),
          title: "充值"
        },
        {
          url: "/batch/batchPayment",
          imgUrl: require("@/assets/images/pay-icon.png"),
          title: "批量打款"
        }
      ],
      //-----------------列表查询模型必要配置start
      filterData: {
      },
      queryBalance() {
        this.$http
          .get(
            "/jiaxin-web/dashboard/getMchBalance.do",
            {}
          )
          .then((res)=>{
            this.balance=res.data.depositBalance;
          });
      },
      queryMonthSummary() {
        this.$http
          .get(
            "/jiaxin-web/dashboard/monthSummary.do",
            {}
          )
          .then((res)=>{
            console.log(res);
            this.transCount=res.data.transCount;
            this.transAmount=res.data.transAmount;
          });
      },
      queryListUrl: "/jiaxin-web/dashboard/accountTrans.do" //列表查询url
      // formatFilterData:null, 过滤数据不能直接使用，启用该方式
      //-----------------列表查询模型必要配置end
    };
  },
  created() {
    this.queryBalance();
    this.queryMonthSummary();
  },
  mounted() {},
  computed: {
    ...mapGetters(["userName"])
  },
  methods: {
    linkTo(url) {
      this.$router.push(url);
    }
  }
};
</script>

<style lang="scss" scoped>
.home {
  overflow-x: hidden;
  padding: 30px 20px;
  max-width: 1380px;
  margin: 0 auto;
  .account {
    height: 320px;
    background: url(../../assets/images/home-bj.png) #fff center bottom
      no-repeat;
    position: relative;
    .total {
      position: absolute;
      top: 110px;
      left: 70px;
      font-size: 20px;
      overflow: hidden;
      dt {
        width: 100px;
        height: 100px;
        background: url(../../assets/images/account-bj.png) no-repeat;
        float: left;
      }
      dd {
        margin-left: 140px;
        line-height: 40px;
        &.money {
          color: #13a2c0;
        }
      }
    }
    .month {
      position: absolute;
      width: 400px;
      height: 160px;
      border: 1px solid #dcdcdc;
      border-radius: 3px;
      top: 60px;
      right: 90px;
      background: #fff;
      box-sizing: border-box;
      padding: 0 25px;
      .hd {
        line-height: 45px;
        border-bottom: 1px solid #dcdcdc;
        color: #666666;
      }
      .bd {
        display: flex;
        text-align: left;
        line-height: 2.4em;
        padding: 10px 0;
        dl {
          flex: 1;
        }
        dd {
          margin: 0;
          font-size: 22px;
          color: #13a2c0;
          span {
            font-size: 14px;
            color: #333;
          }
        }
      }
    }
  }
  .info {
    margin-top: 30px;
    display: flex;
    height: 490px;
    .record {
      margin-right: 30px;
      background: #fff;
      padding: 40px 50px;
      flex: 1;
      .hd {
        font-size: 18px;
        margin-bottom: 40px;
        a {
          float: right;
          font-size: 14px;
          color: #13a2c0;
        }
      }
    }
    .rct {
      width: 500px;
      height: 520x;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      margin: -15px 0;
      & > div {
        background: #fff;
        &:hover {
          background: #fafafa;
          cursor: pointer;
        }
        flex: 1;
        overflow: hidden;
        margin: 15px 0;
        border-left: 6px solid #13a2c0;
        border-radius: 4px;
        display: flex;
        align-items: center;
        img {
          margin: 0 25px 0 80px;
        }
      }
    }
  }
}
</style>

<style lang="scss">
.home {
  .el-table__empty-block:before {
    margin-top: 60px;
  }
}
</style>
