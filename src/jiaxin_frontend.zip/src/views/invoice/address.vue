<template>
  <div class="address">
    <h3 class="page-title">
      <el-popover
        placement="right"
        v-model="visible"
        trigger="manual"
        visible-arrow="true"
        width="320"
      >
        <span class="iconfont icon-tishi11 c-yellow mgr-10"></span>
        您已创建{{addressLength}}个邮寄地址，最多可创建20个
        <span slot="reference">邮寄地址</span>
      </el-popover>
    </h3>
    <div class="add">
      <span @click="addAddress">新增邮寄地址</span>
    </div>
    <XTableComponent ref="tableList" :url="queryListUrl" type="get" @change="setNum">
      <template slot="table">
        <el-table-column prop="receiverName" label="收件人" align="center"></el-table-column>
        <el-table-column prop="receiverPhone" label="电话"></el-table-column>
        <el-table-column prop="receiverAddress" label="地址"></el-table-column>
        <el-table-column prop="payerCnyShortName" label="操作">
          <template slot-scope="scope">
            <div class="eidtaddress">
              <span @click="editAddress(scope.row)">修改</span> |
              <span @click="deleteAddress(scope.row)">删除</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="payerCnyShortName" label="管理">
          <template slot-scope="scope">
            <span v-if="scope.row.status.value==1" class="default-btn active">默认地址</span>
            <span
              v-if="scope.row.status.value!=1"
              @click="setDefault(scope.row)"
              class="default-btn"
            >设为默认</span>
          </template>
        </el-table-column>
      </template>
    </XTableComponent>
    <el-dialog :title="diaTitle" :visible.sync="dialogVisible" width="680px">
      <div class="addAddress">
        <el-form
          class="e-form"
          :model="formData"
          ref="ruleForm"
          label-width="150px"
          label-position="left"
          :rules="rules"
        >
          <el-form-item label="收件人姓名：" prop="receiverName">
            <el-input size="small" v-model="formData.receiverName"></el-input>
          </el-form-item>
          <el-form-item label="手机号码：" prop="receiverPhone">
            <el-input size="small" v-model="formData.receiverPhone"></el-input>
          </el-form-item>
          <XCascaderCompoent
            :props="{value:'desc'}"
            url="/jiaxin-web/common/area.do"
            label="所在地区："
            name="provinceCity"
            v-model="formData.provinceCity"
          />
          <el-form-item label="详细地址：" prop="receiverAddress">
            <el-input
              size="small"
              v-model="formData.receiverAddress"
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4}"
            ></el-input>
          </el-form-item>
          <el-form-item label="邮政编码：" prop="expectOrderDate">
            <el-input size="small"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button @click="save" type="primary">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import XTableComponent from "@/components/FilterTable/XTableComponent";
import XCascaderCompoent from "@/components/FilterTable/XCascaderCompoent";
export default {
  name: "example",
  components: {
    XTableComponent, //表格组件
    XCascaderCompoent
  },
  data() {
    return {
      visible: false,
      dialogVisible: false,
      dialogType: 0,
      addressLength: 0,
      formData: {
        receiverName: "",
        receiverPhone: "",
        receiverAddress: "",
        provinceCity: []
      },
      rules: {
        receiverName: [
          { required: true, message: "请填写收件人姓名", trigger: "blur" }
        ],
        receiverPhone: [
          { required: true, message: "请填写手机号码", trigger: "blur" },
          {
            pattern: /^1[3456789]\d{9}$/,
            message: "目前只支持中国大陆的手机号码"
          }
        ],
        receiverAddress: [
          { required: true, message: "请填写详细地址", trigger: "blur" }
        ],
        provinceCity: [
          { required: true, message: "请选择所在地区", trigger: "blur" }
        ]
      },
      addressOptions: [],
      queryListUrl: "/jiaxin-web/address/getAddressList.do" //列表查询url
    };
  },
  created() {},
  mounted() {
    setTimeout(() => {
      this.visible = true;
    }, 400);
  },
  computed: {
    diaTitle() {
      const tilte = this.dialogType === 0 ? "新增邮寄地址" : "修改邮寄地址";
      return tilte;
    }
  },
  methods: {
    setNum(data) {
      this.addressLength = data.length;
    },
    setDefault({ id }) {
      this.$http.post("/jiaxin-web/address/setDefault.do", { id }).then(res => {
        this.$refs["tableList"].reload();
        this.$message({
          message: "设置成功！",
          type: "success"
        });
      });
    },
    deleteAddress({ id }) {
      this.$http.post("/jiaxin-web/address/delete.do", { id }).then(res => {
        this.$refs["tableList"].reload();
        this.$message({
          message: "删除成功！",
          type: "success"
        });
      });
    },
    queryEditAddAddress() {
      const url =
        this.dialogType == 1
          ? "/jiaxin-web/address/update.do"
          : "/jiaxin-web/address/add.do";
      return this.$http.post(url, this.formData);
    },
    addAddress() {
      this.dialogType = 0;
      this.dialogVisible = true;
      this.$refs["ruleForm"] && this.$refs["ruleForm"].resetFields();
    },
    editAddress(data) {
      this.dialogType = 1;
      this.dialogVisible = true;
      this.$nextTick(() =>
        Object.assign(this.formData, data, {
          status: data.status.value,
          provinceCity: [
            `${data.receiverProvinceName}-${data.receiverProvinceCode}`,
            `${data.receiverCityName}-${data.receiverCityCode}`,
            `${data.receiverDistrictName}-${data.receiverDistrictCode}`
          ]
        })
      );
    },

    async save() {
      await this.$refs["ruleForm"].validate();
      await this.queryEditAddAddress();
      this.dialogVisible = false;
      this.$refs["tableList"].reload();
      this.$message({
        message: this.dialogType === 1 ? "修改成功！" : "新增成功！",
        type: "success"
      });
    }
  },
  watch: {
    "formData.provinceCity"(val) {
      if (val.length > 0) {
        this.formData.receiverProvinceCode = val[0].split("-")[1];
        this.formData.receiverProvinceName = val[0].split("-")[0];
        this.formData.receiverCityCode = val[1].split("-")[1];
        this.formData.receiverCityName = val[1].split("-")[0];
        this.formData.receiverDistrictCode = val[2].split("-")[1];
        this.formData.receiverDistrictName = val[2].split("-")[0];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.c-yellow {
  color: #ffc836;
  margin-right: 10px;
}
.address {
  .bd {
    color: #666666;
    line-height: 3em;
    padding-top: 20px;
    label {
      font-weight: normal;
      color: #333;
      width: 120px;
      display: inline-block;
    }
  }
  .add {
    padding: 20px 0;
    span {
      color: #13a2c0;
      cursor: pointer;
    }
  }
  .default-btn {
    color: #13a2c0;
    cursor: pointer;
    background: none;
    border: 0;
    border-radius: 2px;
    box-sizing: border-box;
    line-height: 30px;
    text-align: center;
    vertical-align: middle;
    display: inline-block;
    width: 80px;
    height: 30px;
    &.active {
      background: #fff9e3;
      border: 1px solid #ff7f22;
      line-height: 28px;
      color: #ff7f22;
    }
  }
  .eidtaddress {
    color: #13a2c0;
    span {
      cursor: pointer;
      margin: 0 5px;
    }
  }
}
</style>
<style lang="scss">
.address {
  .el-cascader--medium {
    font-size: 14px;
    line-height: 36px;
    width: 100%;
  }
}
</style>

