import Vue from 'vue'
import 'normalize.css/normalize.css'
import Element from 'element-ui'
import '@/styles/theme/index.css' 
// import 'element-ui/lib/theme-chalk/index.css'
import '@/styles/index.scss' 
import 'babel-polyfill'
import '@/assets/font/iconfont.css'
import App from './App'
import router from './router'
import store from './store'
import './permission' 
import * as filters from './filters' 
import request from '@/utils/request'
import vPermission from "@/directive/permission";
// import plugin from "./plugin";
import datePicker from '@/directive/datePicker.js';
datePicker.install(Vue);
Vue.use(Element, {
  size: 'medium',
})

// Vue.use(plugin)
Vue.use(vPermission)

Vue.prototype.$http = request;
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
