<template>
  <div class="form-edit">
    <div class="form-title">{{title[type]}}</div>
    <el-form
      :model="value"
      :label-width="labelWidth"
      ref="ruleForm"
      :label-position="labelPosition"
      v-bind="$attrs"
      :type="type"
      :hide-required-asterisk="type==2"
      :show-message="type!=2"
    >
      <slot></slot>
      <div class="tool" :style="{paddingLeft:labelWidth}" v-if="type!=2">
        <el-button @click="resetForm">重置</el-button>
        <el-button
          type="primary"
          v-loading="loading"
          @click="submitForm"
        >{{type==0? addBtnText: editBtnText}}</el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
export default {
  props: {
    value: Object,
    type: Number,
    props: Object,
    // rules: Object,
    labelPosition: {
      type: String,
      default: "left"
    },
    labelWidth: {
      type: String,
      default: "120px"
    },
    addBtnText: {
      type: String,
      default: "新增"
    },
    editBtnText: {
      type: String,
      default: "保存"
    }
  },
  data() {
    return {
      store: null,
      title: ["新增", "编辑", "详情"]
    };
  },
  methods: {
    submitForm() {
      this.$refs["ruleForm"].validate(valid => {
        console.log("suceess");
      });
    },
    resetForm() {
      this.$refs["ruleForm"].resetFields();
    },
    querySave() {
      //新增、编辑保存操作
      this.$http
        .post(this.props.url[this.type], this.props.queryData)
        .then(({ data }) => {
          this.loading = false;
          this.$emit("success", data);
        });
    },
    queryDetail() {
      //编辑、详情查询数据并赋值
      // this.$http[this.props.type || "post"](
      //   this.props.url[2],
      //   this.props.queryData
      // ).then(({ data }) => {
      //   this.val = data;
      //   this.$emit("update", data);
      // });
      const returnVal = {
        username: "zhuwencheng",
        region: "beijing",
        requestTime: [],
        fileList: [
          {
            name: "food.jpeg",
            url:
              "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100"
          },
          {
            name: "food2.jpeg",
            url:
              "https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100"
          }
        ]
      };
      this.$emit("input", returnVal);
    }
  },
  mounted() {},
  created() {
    this.$route.meta.title = this.title[this.type];
    // this.type == 2 ? (this.$attrs.rules = {}) : "";
    this.type!=0 ? this.queryDetail() : "";
  }
};
</script>

<style lang="scss" scoped>
.form-edit {
  .form-title {
    line-height: 2em;
    border-bottom: 1px dashed #dadada;
    margin-bottom: 40px;
    font-weight: bold;
    padding-bottom: 15px;
  }
  form {
    padding-left: 20px;
  }
  .tool {
    padding-top: 50px;
  }
}
</style>

