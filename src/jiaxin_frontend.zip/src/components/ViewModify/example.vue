<template>
  <div>
    <XViewModify :queryDataUrl="queryDataUrl" :saveUrl="saveUrl" :queryParams="queryParams">
      <xVMItem label="下单时间" prop="expectOrderDate">
        <template slot-scope="{ todo }">
          <el-date-picker
            v-model="filterData.expectOrderDate"
            type="datetimerange"
            range-separator="至"
            :default-time="['00:00:00', '23:59:59']"
            value-format="yyyy-MM-dd HH:mm:ss"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            slot="edit"
          ></el-date-picker>
        </template>
      </xVMItem>
    </XViewModify>
  </div>
</template>

<script>
import XFilterComponent from "./component/XFilterComponent";
export default {
  name: "example",
  components: {
    XFilterComponent
  },
  data() {
    return {
      queryDataUrl:'./inter_manage/userManage/getUserDetail',
      queryParams:{
        id:36
      },
      saveUrl:'./inter_manage/organizationManage/getOrgInfoList'
    };
  },
  created() {},
  mounted() {},
  methods: {},
  computed: {}
};
</script>
<style lang="scss" scoped>
</style>