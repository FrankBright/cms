module.exports = {
  // 生产环境
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
  BASE_API: '/',
  ASSET_PATH: '/'
}
