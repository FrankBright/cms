const IMG_UPLOAD_URL = {
    dev: '/mwallet_api/giftcardActivity/upload',
    sit: '/mwallet_api/giftcardActivity/upload',
    prod: '/mpc-svcadmin/giftcardActivity/upload',
}

const imgUrl = IMG_UPLOAD_URL[process.env.ENV_CONFIG]
export default imgUrl