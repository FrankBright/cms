import Vue from 'vue'
import Router from 'vue-router'
import { asyncRouterMap } from './asynRouter'
Vue.use(Router);
const constantRouterMap = [{
    path: '/',
    redirect: '/home',
}, {
    path: '/login',
    component: () =>
        import('@/views/login/index'),
    hidden: true,
    meta: {
        noNeedLogin: true
    }
}, {
    path: '/404',
    component: () =>
        import('@/views/errorPage/404'),
    hidden: true,
    meta: {
        noNeedLogin: true
    }
}, {
    path: '/401',
    component: () =>
        import('@/views/errorPage/401'),
    hidden: true,
    meta: {
        noNeedLogin: true
    }
}]
export { asyncRouterMap, constantRouterMap };

export default new Router({
    scrollBehavior: () => ({
        y: 0
    }),
    routes: constantRouterMap
})
