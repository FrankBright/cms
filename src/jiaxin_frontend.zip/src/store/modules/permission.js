import { asyncRouterMap } from "@/router";
// import command from "@/router/main.js";
/**
 * 通过meta.role判断是否与当前用户权限匹配
 * @param roles
 * @param route
 */
function hasPermission(roles, route) {
  if (route.meta && route.meta.roles) {
    return roles.some(role => route.meta.roles.indexOf(role) >= 0)
  } else {
    return true
  }
}

/**
 * 递归过滤异步路由表，返回符合用户角色权限的路由表
 * @param asyncRouterMap
 * @param roles
 */
function filterAsyncRouter(asyncRouterMap, roles) {
  const accessedRouters = asyncRouterMap.filter(route => {
    if (hasPermission(roles, route)) {
      if (route.children && route.children.length) {
        route.children = filterAsyncRouter(route.children, roles)
      }
      return true
    }
    return false
  })
  return accessedRouters
}

const permission = {
  state: {
    allRouters: {},
    currentNav: ''
  },
  mutations: {
    SET_ROUTERS: (state, json) => {
      const {
        i,
        asyncRouters
      } = json
      state.allRouters[i] = asyncRouters
    },
    UPDATE_SIDERBAR(state, type) {
      let flag1 = type in state.allRouters,
        flag2 = type != state.currentNav
      if (flag1 && flag2) {
        state.currentNav = type
      }
    }
  },
  actions: {
    GenerateRoutes({
      commit
    }, data) {
      return new Promise(resolve => {
        const {
          roles,
          to
        } = data
        var addRouters = [],
          asyncRouters = []
          for (var i = 0; i < asyncRouterMap.length; i++) {
            asyncRouters = filterAsyncRouter(asyncRouterMap[i].routes, roles);
            addRouters = addRouters.concat(asyncRouters);
            commit('SET_ROUTERS', {
              i: asyncRouterMap[i].name,
              asyncRouters
            })
          }
        addRouters.push({
          path: '*',
          redirect: '/404',
          hidden: true
        })
        resolve(addRouters)
      })
    },
    UpdateSiderbar({
      commit
    }, data) {
      const {
        to
      } = data
      const type = to.meta.nav||to.meta.name;
      commit('UPDATE_SIDERBAR', type)
    }
  }
}

export default permission
