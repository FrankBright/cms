// import Cookies from 'js-cookie'

const token = 'X-Token'

export function getToken() {
  return sessionStorage.getItem(token)
}

export function setToken(data) {
  return sessionStorage.setItem(token, data)
}

export function removeToken() {
  return sessionStorage.removeItem(token)
}
