import axios from 'axios'
import { Message, Loading, MessageBox } from 'element-ui'
import store from '@/store'
let loading;
// create an axios instance
const service = axios.create({
    // baseURL: 'https://dby.ipaynow.cn/',
    // baseURL: process.env.BASE_API, // api的base_url
    timeout: 5000, // request timeout
})
// request interceptor
service.interceptors.request.use(config => {
    // if (typeof config.data == 'object' && config.url.indexOf('report-manager') == -1) {
    //   config.data = qs.stringify(config.data, { arrayFormat: 'repeat' });
    // }
    loading = Loading.service({
        fullscreen: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.3)'
    });
    return config
}, error => {
    Promise.reject(error)
})

service.interceptors.response.use(
    response => {
        const res = response.data
        loading.close();
        if (res.code != 0) {
            //登录状态失效,重定向登录页
            if (res.code == 2) {
                MessageBox.confirm(
                    '您的登录状态已失效，可以取消继续留在该页面，或者重新登录',
                    '确定登出',
                    {
                        confirmButtonText: '重新登录',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }
                ).then(() => {
                    store.dispatch('FedLogOut').then(() => {
                        location.reload();
                    })
                })
            } else {
                return Promise.reject(res.msg);
            }
            
        } else {
            return res;
        }
    },
    error => {
        loading.close();
        Message({
            message: '网络异常!',
            type: 'error',
            duration: 5 * 1000
        })
        return Promise.reject('网络异常!')
    }
);

export default {
    post(url, params, hasFailTip = true) {
        return service.post(url, params).then(res => {
            return res;
        }, err => {
            hasFailTip && Message({
                message: err,
                type: 'error',
                duration: 5 * 1000
            });
            return Promise.reject(err);
        })
    },
    get(url, params, hasFailTip = true) {
        return service({
            method: 'get',
            url: url,
            params
        }).then(
            res => {
                return res;
            },
            err => {
                hasFailTip && Message({
                    message: err,
                    type: 'error',
                    duration: 5 * 1000
                });
                return Promise.reject(err);
            }
        )
    }
}

