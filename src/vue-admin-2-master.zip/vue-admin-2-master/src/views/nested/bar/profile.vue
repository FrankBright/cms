<template>
  <div style="margin-top:30px;">
    <el-alert title="Children: Profile" type="success" :closable="false">
    </el-alert>
  </div>
</template>
