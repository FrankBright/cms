const transTypeAry = [{
    value: 0,
    label: '付款'
}, {
    value: 1,
    label: '充值'
}, {
    value: 2,
    label: '提现'
}, {
    value: 3,
    label: '转账'
}, {
    value: 4,
    label: '换汇'
}, {
    value: 5,
    label: '结算入款'
}]
const transStatusAry = [{
    value: 0,
    label: '初始状态'
}, {
    value: 1,
    label: '处理中'
}, {
    value: 2,
    label: '成功'
}, {
    value: 3,
    label: '失败'
}, {
    value: 4,
    label: '订单关闭'
}]
const MoneyAccTypeAry = [{
    value: 0,
    label: '对私'
}, {
    value: 1,
    label: '对公'
}]
const MoneyDcTypeAry = [{
    value: 0,
    label: '借'
}, {
    value: 1,
    label: '贷'
}]
const payStatusAry = [{
    value: 0,
    label: '初始化'
}, {
    value: 1,
    label: '已冻结'
}, {
    value: 2,
    label: '可下载'
}, {
    value: 3,
    label: '待确认'
}, {
    value: 4,
    label: '成功'
}, {
    value: 5,
    label: '失败'
}]
export default {  // 哪里有用到请注释说明  用 ，分隔
    transTypeAry,   // 交易管理交易 明细 ，详情
    transStatusAry, // 交易管理交易 明细，详情
    MoneyAccTypeAry,// 交易管理交易 明细，详情
    MoneyDcTypeAry,// 交易管理交易 明细，详情
    payStatusAry,
}

