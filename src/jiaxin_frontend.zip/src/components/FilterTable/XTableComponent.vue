<template>
  <div class="table-main">
    <el-table
      :data="tableData"
      border
      header-align="center"
      :header-cell-style="{background: '#f4f4f4',color:'#333'}"
      element-loading-text="拼命加载中"
      v-loading="loading"
      v-bind="$attrs"
      ref="table"
      @selection-change="onSelect"
    >
      <slot name="table"></slot>
    </el-table>
    <el-pagination
      class="page"
      background
      @current-change="resetQueryData"
      :current-page="pagination.current"
      :page-size="pagination.size"
      layout="total, prev, pager, next, jumper"
      :total="pagination.total"
      v-if="pagination.total"
    ></el-pagination>
  </div>
</template> 

<script>
export default {
  props: ["url", "filterData", "formatFilterData", "type"], //formatFilterData用于过滤提交需二次转化的场景
  data() {
    return {
      tableData: [],
      loading: false,
      queryData: {},
      pagination: {
        current: 1,
        total: null,
        size: 20
      }
    };
  },
  methods: {
    resetQueryData(page, isFilter) {
      setTimeout(() => {
        const lData = isFilter ? this.filterData : this.queryData;
        this.pagination.current = page;
        const data = Object.assign(
          {},
          lData,
          this.formatFilterData,
          this.pagination
        );
        this.queryData = JSON.parse(JSON.stringify(data));
      }, 1);
    },
    getQueryData() {
      return this.queryData(); //暴露查询字段供外部调用
    },
    queryTableData() {
      // console.log(JSON.parse(JSON.stringify(this.queryData)), "table查询");
      // this.loading = true;
      this.$http[this.type || "post"](this.url, this.queryData).then(res => {
        this.loading = false;
        const result = res.data;
        this.tableData = result.records;
        this.pagination.total = result.total;
        this.$emit("change", this.tableData);
      });
    },
    clearSelection() {
      //多封装一层
      this.$refs.table.clearSelection();
    },
    onSelect(res) {
      //多封装一层
      this.$emit("selection-change", res);
    },
    reload() {
      this.queryTableData();
    }
  },
  watch: {
    queryData() {
      //监听查询条件，改变就查询
      if (!this.url) return;
      this.queryTableData();
    }
  },
  mounted() {
    this.resetQueryData(1, true);
  }
};
</script>

<style lang='scss'>
.table-main {
  // margin-top: 20px;
  background: #fff;
  .el-table th {
    text-align: center;
  }
  .el-table {
    td {
      text-align: center;
    }
  }
}
.page {
  text-align: right;
  padding: 10px;
}
</style > 
