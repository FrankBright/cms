<template>
  <div class="rechargeRecord">
    <h3 class="page-title">充值记录</h3>
    <!-- 过滤表单 start-->
    <XFilterComponent @submit="filterQuery" :formData="filterData" :rules="rules" btnToTop>
      <!-- 下单时间 -->
      <el-form-item label="时间" prop="date" style="width:50%">
        <el-date-picker
          v-model="filterData.date"
          type="datetimerange"
          range-separator="至"
          :default-time="['00:00:00', '23:59:59']"
          value-format="yyyy-MM-dd HH:mm:ss"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <template slot="othertool">
        <!-- <el-button icon="el-icon-download" @click="download">下载列表</el-button> -->
        <a :href="downLink" target="_blank" class="download-btn"><i class="el-icon-download"></i>下载列表</a>
      </template>
    </XFilterComponent>
    <!-- 过滤表单 end-->
    <!-- 表格 start-->
    <XTableComponent ref="tableList" :url="queryListUrl" :filterData="filterData">
      <template slot="table">
        <el-table-column prop="transDate" label="入账时间"></el-table-column>
        <el-table-column prop="transId" label="流水号"></el-table-column>
        <el-table-column prop="amount" label="金额（元）">
          <template slot-scope="scope">{{scope.row.amount&&scope.row.amount.toFixed(2)}}</template>
        </el-table-column>
        <el-table-column prop="actualAmount" label="实际到账金额（元）">
          <template slot-scope="scope">{{scope.row.actualAmount&&scope.row.actualAmount.toFixed(2)}}</template>
        </el-table-column>
      </template>
    </XTableComponent>
    <!-- 表格 end-->
  </div>
</template>

<script>
import XFilterComponent from "@/components/FilterTable/XFilterComponent";
import XTableComponent from "@/components/FilterTable/XTableComponent";
import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
import qs from "qs";
export default {
  name: "example",
  components: {
    XFilterComponent, //过滤表单组件
    XTableComponent, //表格组件
    XSelectCompoent //下拉二次封装
  },
  data() {
    return {
      //-----------------列表查询模型必要配置start
      filterData: {
        //过滤条件数据，所有查询字段需实现定义
        // startTime: "2019-09-25 10:10:20",
        // endTime: "2019-09-26 10:10:22",
        date: [] //时间范围默认是前端控件是数组类型，不符合接口类型，需进行watch进行分别赋值，建议后端更改接口类型最为合适
      },
      rules: {
        //过滤提交校验、非必填:样例如下
        // userName: [
        //   { required: true, message: "请输入用户名", trigger: "blur" },
        //   { min: 1, max: 7, message: "长度在 1 到 7 个字符", trigger: "blur" }
        // ]
      },
      queryListUrl: "/jiaxin-web/recharge/rechargeList.do" //列表查询url
      // formatFilterData:null, 过滤数据不能直接使用，启用该方式
      //-----------------列表查询模型必要配置end
    };
  },
  created() {},
  mounted() {},
  computed: {
    downLink(){
      const query = qs.stringify(this.filterData);
      return "/jiaxin-web/recharge/exportRechargeList.do?" + query;
    }
  },
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    download() {
      console.log("下载参数", this.filterData);
    }
  },
  watch: {
  }
};
</script>
<style lang="scss" scoped>
.rechargeRecord {
  .download-btn{
    display: inline-block;
    line-height: 1;
    cursor: pointer;
    background: #FFF;
    border: 1px solid #DCDFE6;
    color: #606266;
    text-align: center;
    box-sizing: border-box;
    margin-left:10px;
    padding: 10px 20px;
    border-radius: 4px;
    vertical-align: baseline;
  }
}
</style>