<template>
    <ul>
        <li v-for='(txt, index) in titles' 
            :key='index' 
            :style="{'margin-right': index != titles.length - 1 && '76px'}"
            :class='{active: activeIndex == index+1, success: activeIndex > index + 1}'>
            <i v-if='activeIndex > index + 1' class='iconfont icon-check index'></i>
            <i v-else class='index' style='font-size: 16px;'>{{ index + 1}}</i>
            <span :style="{'margin-right': index != titles.length - 1 && '76px'}">{{txt}}</span>
            <i class="iconfont icon-gengduo" v-if='index != titles.length - 1'></i>
        </li>
    </ul>
</template>


<script>
export default {
    props: ['titles', 'activeIndex']
}
</script>

<style lang="scss" scoped>
ul{
    height: 80px;
    line-height: 80px;
    font-size: 0;
    text-align: center;
    padding: 0;
    border-bottom: 1px solid #DCDCDC;
    margin:-30px -40px 20px;
    li{
        display: inline-block;
        vertical-align: middle;
        font-size: 16px;
        color: #909399;
        &.active{
            color: #303133;
        }
        &.success{
            color: #5CB87A;
        }
        i.index{
            color: inherit;
            font-style: normal;
            display: inline-block;
            margin-right: 15px;
            width: 24px;
            font-size: 12px;
            height: 25px;
            line-height: 24px;
            vertical-align: middle;
            border: 1px solid currentColor;
            border-radius: 50%;
        }
        .iconfont{
            color: #C0C4CC;
            font-size: 28px;
            vertical-align: middle;
        }
    }
}
</style>

