<template>
  <div class="app-wrapper" :class="classObj">
    <headerBar ></headerBar>
    <sidebar class="sidebar-container"></sidebar>
    <div class="wrapper">
      <div class="main-container layout-wrapper">
        <Breadcrumb class='link'></Breadcrumb>
        <div class="content-wrapper">
          <div class="content">
            <!-- <navbar></navbar> -->
            <!-- <tags-view></tags-view> -->
            <app-main class='main'></app-main>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain, HeaderBar } from './components'
import Breadcrumb from '@/components/Breadcrumb'
export default {
  name: 'layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    HeaderBar,
    Breadcrumb
  },
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar
    },
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
      }
    }
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('closeSideBar', { withoutAnimation: false })
    }
  }
}
</script>

<style lang="scss" scoped>
  @import "src/styles/mixin.scss";
  .app-wrapper {
    @include clearfix;
    position: relative;
    height: 100%;
    width: 100%;
    overflow: hidden;
    background-color: rgb(232, 232, 243);
    &.mobile.openSidebar{
      position: fixed;
      top: 0;
    }
    .main-container{
      padding-top: 50px;
      position: relative;
      padding-left: 240px;
      min-height: 100%;
      padding-bottom: 30px;
      box-sizing: border-box;
      background-clip: content-box;
      background-color: #fff;
      box-shadow: 0 1px 5px 2px rgba(230,230,230,0.50);
    }
    
  }
  .wrapper{
    height: 100%;
    overflow-y: scroll;
    box-sizing: border-box;
    padding-bottom: 60px;
  }
  .drawer-bg {
    background: #000;
    opacity: 0.3;
    width: 100%;
    top: 0;
    height: 100%;
    position: absolute;
    z-index: 999;
  }
.link{
  position: absolute;
  margin-top: -25px;
}
</style>
<style lang="scss">
  #app div.main-container{
    .content-wrapper{
        min-height: 100%;
        position: relative;
        padding-bottom: 40px;
        box-sizing: border-box;
        .content{
            min-height: 100%;
            font-size: 14px;
            color: #000000;
            letter-spacing: 0;
            padding: 30px 40px 0;
        }
    }
  }
</style>
