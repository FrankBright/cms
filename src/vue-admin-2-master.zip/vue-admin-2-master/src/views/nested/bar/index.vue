<template>
  <div class="app-container">
    <code>Parent View: Bar</code>
    <img src="https://wpimg.wallstcn.com/be29a7d2-5ccf-4a2b-888d-8a6c2bbb7aac.png">
    <router-view></router-view>
  </div>
</template>
