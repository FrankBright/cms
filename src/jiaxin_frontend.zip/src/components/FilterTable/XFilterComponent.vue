<template>
  <div class="filter-w">
    <el-form
      class="e-form"
      :model="formData"
      ref="ruleForm"
      label-width="7em"
      :label-position="labelPosition"
      :rules="rules"
    >
      <div class="f-box" :style="{maxHeight:status==1?'1000px':hideHeight+'px'}">
        <slot></slot>
      </div>
      <div :class="{tool:true, btntotop: btnToTop!=undefined}">
        <span v-if="hideHeight" @click="triggerStatus" class="hidetool">{{statusText[status]}}</span>
        <!-- <el-button @click="resetForm">重置</el-button> -->
        <el-button type="primary" @click="submitForm">搜索</el-button>
        <slot name="othertool"></slot>
      </div>
    </el-form>
  </div>
</template>

<script>
export default {
  props: ["formData", "rules", "hideHeight", "btnToTop"],
  data() {
    return {
      status: 0,
      statusText: ["更多筛选条件", "折叠"],
      labelPosition: "left"
    };
  },
  methods: {
    triggerStatus() {
      this.status ? (this.status = 0) : (this.status = 1);
    },
    submitForm() {
      this.$refs["ruleForm"].validate(valid => {
        if (valid) {
          this.$emit("submit");
        } else {
          return false;
        }
      });
    },
    resetForm() {
      this.$refs["ruleForm"].resetFields();
      this.$emit("submit");
    }
  },
  mounted() {}
};
</script>

<style lang='scss'>
.filter-w {
  background: #fff;
  margin-bottom: 20px;
  overflow: hidden;
  position: relative;
  padding: 15px 0;
  .e-form {
    font-size: 0;
    .f-box {
      transition: all ease 0.3s;
      max-height: 10000px;
      overflow-y: hidden;
      margin-right: -20px;
    }
  }
  .tool {
    text-align: right;
    display: inline-block;
    float: right;
    font-size: 14px;
    &.btntotop {
      margin-top: -58px;
    }
    .hidetool {
      font-size: 14px;
      margin-right: 20px;
      cursor: pointer;
      color: #409eff;
    }
  }
  .el-form-item {
    width: 25%;
    padding-right: 2%;
    display: inline-block;
    box-sizing: border-box;
  }
  .el-select,
  .el-range-editor {
    width: 100%;
  }
}
</style >
