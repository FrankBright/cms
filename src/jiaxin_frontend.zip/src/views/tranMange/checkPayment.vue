<template>
  <div id="wrapper" class="wrapper-box">
    <Title :titles="titles" activeIndex="2"/>
    <div class="tip">
      <span>
        计划打款总额{{detail.totalAmount}}元，服务费{{detail.totalFeeAmount}}元，共计{{detail.totalAmount + detail.totalFeeAmount}}元，账户余额{{detail.balanceAmount}}元。
        <span
          v-if="status == 2"
        >
          还需通过银行转账充值
          <font color="#13A2C0">{{-detail.rechargeAmount}}</font>元。
        </span>
      </span>
      <el-button
        type="primary"
        v-if="status == 1"
        @click="onShow()"
      >进行打款</el-button>
      <el-button type="primary" v-else-if="status == 2" @click="onGetAccount">查看充值信息</el-button>
    </div>
    <XFilterComponent @submit="filterQuery" :formData="filterData" :rules="rules" btnToTop>
      <!-- 下单时间 -->
      <el-form-item label="收款人" prop="receiver" label-width="60px" style="width:34%">
        <el-input size="small" placeholder="可输入平台id/姓名/手机号/身份证号检索" v-model="filterData.receiver"></el-input>
      </el-form-item>
      <XSelectCompoent
        label="签约状态"
        :clearable="true"
        name="status"
        url="/jiaxin-web/common/dataDic.do?dataTypeNo=1001"
        v-model="filterData.status"
      ></XSelectCompoent>

      <template slot="othertool">
        <a
          :href="'/jiaxin-web/order/exportOrders.do?current=1&size=100&batchNo=' +
          $route.query.batchNo"
          target="_blank"
          class="download-btn"
        >
          <i class="el-icon-download"></i>下载列表
        </a>
        <!-- <el-button icon="el-icon-download" @click="download">下载列表</el-button> -->
      </template>
    </XFilterComponent>

    <XTableComponent ref="tableList" :url="queryListUrl" :filterData="filterData">
      <template slot="table">
        <el-table-column prop="platformId" label="平台id" align="center" width="80"></el-table-column>
        <el-table-column prop="userName" label="姓名"></el-table-column>
        <el-table-column prop="userMobile" label="手机号"></el-table-column>
        <el-table-column prop="userIdCardNo" label="身份证号"></el-table-column>
        <el-table-column prop="userBankCardNo" label="银行账号"></el-table-column>
        <el-table-column prop="salaryAmount" label="打款金额(元)" align="center"></el-table-column>
        <el-table-column prop="signStatus" label="签约状态" align="center" width="80">
          <template slot-scope="scope">{{scope.row.signStatus.desc}}</template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="100">
          <template slot-scope="scope">
            <span
              v-if="scope.row.status.code == 0"
              class="link"
              @click="onCancel(scope.row)"
            >取消该笔</span>
            <span v-else>已{{scope.row.status.desc}}</span>
          </template>
        </el-table-column>
      </template>
    </XTableComponent>
    <!-- 充值信息 -->
    <el-dialog title="充值信息" :visible.sync="dialogVisible" width="680px">
      <div class="rechargeInfo">
        <p>付款账户名：{{account.accountName}}</p>
        <!-- <p>付款账户号：{{account.accountNo}}</p> -->
        <hr>
        <p class="m">
          <font color="#13A2C0">请将充值金额从付款账户汇到以下账户，以完成充值。</font>
        </p>
        <div class="info">
          <p>账户名：{{account.recvAccountName}}</p>
          <p>开户行：{{account.recvAccountNo}}</p>
          <p>账户号：{{account.recvBankName}}</p>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">知道了</el-button>
      </span>
    </el-dialog>
    <el-dialog title="打款信息" :visible.sync="dialogVisible1" width="680px" @close="password = ''">
      <div class="rechargeInfo">
        <div class="info">
          <p>打款笔数： {{info.count}}</p>
          <p>打款总额： {{info.sumSalaryAmount}}元</p>
          <p>实收手续费：{{info.sumFeeAmount}}元</p>
        </div>
        <p class="m">
          <font color="#13A2C0">请确认打款信息无误，提交后不可再修改</font>
        </p>
        <div class="flex">
          <label for>支付密码</label>
          <el-input size="small" type="password" v-model="password"></el-input>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible1 = false">取消</el-button>
        <el-button type="primary" @click="onSubmit">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import md5 from "js-md5";
import Title from "@/components/title.vue";
import XFilterComponent from "@/components/FilterTable/XFilterComponent";
import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
import XTableComponent from "@/components/FilterTable/XTableComponent";
export default {
  data() {
    return {
      titles: ["上传打款文件", "核对打款信息", "开始打款"],
      detail: {}, //打款汇总
      filterData: {},
      queryListUrl: "/jiaxin-web/order/getOrders.do",
      options: [],
      status: 1, //充值信息  进行打款
      dialogVisible: false, //充值信息sss
      dialogVisible1: false, //打款信息
      account: {}, //充值信息
      info: {}, //打款信息
      password: ""
    };
  },
  components: {
    Title,
    XSelectCompoent,
    XFilterComponent, //过滤表单组件
    XTableComponent //表格组件
  },
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    download() {
      window.open(
        "/jiaxin-web/order/exportOrders.do?current=1&size=100&batchNo=" +
          this.$route.query.batchNo
      );
    },
    onCancel({ orderNo }) {
      //取消该笔
      this.$confirm("是否取消该笔?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.$http
          .get("/jiaxin-web/order/cancelOrder.do", {
            orderNo
          })
          .then(res => {
            if (res.code == 0) {
              this.$message({
                type: "success",
                message: "取消成功!"
              });
              //queryTableData
              this.$refs.tableList.queryTableData();
              this.getDetail();
            } else {
              this.$message({
                type: "error",
                message: res.msg
              });
            }
            console.log(res);
          });
      });
    },
    onGetAccount() {
      //充值信息
      this.$http.get("/jiaxin-web/fundAccount/baseInfo.do", {}).then(res => {
        this.account = res.data;
        this.dialogVisible = true;
      });
    },
    onShow() {
      //进行打款
      this.$http
        .post("/jiaxin-web/order/getBatchs.do", {
          batchNo: this.$route.query.batchNo,
          current: 1,
          size: 10
        })
        .then(res => {
          this.info = res.data.records[0];
          this.dialogVisible1 = true;
        });
    },
    onSubmit() {
      //打款提交
      let batchNo = this.$route.query.batchNo;
      //确认打款
      let username = sessionStorage.getItem("userName");
      this.$http
        .post("/jiaxin-web/order/confirmBatch.do", {
          batchNo,
          password:
            md5(username + this.password.length + this.password).slice(-16)
        })
        .then(res => {
          console.log(res);
          if (res.code == 0) {
            this.$router.push({
              path: "/batch/startPayment",
              query: {
                batchNo
              }
            });
          } else {
            this.$message({
              type: "error",
              message: res.msg
            });
          }
        });
    },
    getOptions() {
      //获取select枚举
      this.$http
        .get("/jiaxin-web/common/dataDic.do", {
          dataTypeNo: "1001"
        })
        .then(res => {
          this.options = res.data;
        });
    },
    getDetail() {
      this.getOptions();
      this.filterData.batchNo = this.$route.query.batchNo;
      //获取批次汇总
      this.$http
        .get("/jiaxin-web/order/batchSummary.do", {
          batchNo: this.$route.query.batchNo
        })
        .then(res => {
          if (res.code == 0) {
            this.detail = res.data;
            this.status = res.data.rechargeAmount >= 0 ? 1 : 2;
            // this.status = 2;
          } else {
            this.$message({
              type: "error",
              message: res.msg
            });
          }
        });
    }
  },
  mounted() {
    this.getDetail();
  }
};
</script>

<style lang="scss" scoped>
#wrapper {
  .link{
    color: #13a2c0;
    text-decoration: underline;
    cursor: pointer;
  }
  .tip {
    background: #f8f8f8;
    padding: 33px 20px;
    font-size: 14px;
    display: flex;
    margin-bottom: 20px;
    span {
      flex: 1;
      line-height: 36px;
    }
  }
  .rechargeInfo {
    line-height: 32px;
    p {
      color: #646464;
    }
    .m {
      margin: 10px 0;
    }
    hr {
      margin-top: 6px;
    }
    .info {
      background-color: #f8f8f8;
      padding: 10px 20px;
    }
    .flex {
      margin-top: 10px;
      display: flex;
      label {
        display: inline-block;
        width: 100px;
        line-height: 32px;
      }
    }
  }
}
.download-btn{
    display: inline-block;
    line-height: 1;
    cursor: pointer;
    background: #FFF;
    border: 1px solid #DCDFE6;
    color: #606266;
    text-align: center;
    box-sizing: border-box;
    margin-left:10px;
    padding: 10px 20px;
    border-radius: 4px;
    vertical-align: baseline;
  }
</style>
