//  运行不同的命令 切换不同的环境变量
// npm run dev(开发)          :       process.env.ENV_CONFIG='dev'
// npm run build:sit(测试)    :       process.env.ENV_CONFIG='sit'
// npm run build(生产环境))   :       process.env.ENV_CONFIG='prod'

// 基础url
const CONFIG_BASE_URL = {
    dev: '/',//开发
    sit: '/ ',//测试
    prod: '/',//生产
}

// 登录失效跳转
const CONFIG_LOGIN_OUT_URL = {
    dev: '/mwallet/#/login',
    sit: '/mwallet/#/login',
    prod: '/s/mpc-svcadmin/#/login',
}
// 图片上传
const CONFIG_IMG_UPLOAD_URL = {
    dev: '/mwallet_api/giftcardActivity/upload',
    sit: '/mwallet_api/giftcardActivity/upload',
    prod: '/mpc-svcadmin/giftcardActivity/upload',
}
// 导出URL
const CONFIG_EXPORT_BASE_URL = {
    dev: '/mwallet_api',
    sit: '/mwallet_api',
    prod: '/mpc-svcadmin',
}


const BASE_URL = CONFIG_BASE_URL[process.env.ENV_CONFIG]
const LOGIN_OUT_URL = CONFIG_LOGIN_OUT_URL[process.env.ENV_CONFIG]
const IMG_UPLOAD_URL = CONFIG_IMG_UPLOAD_URL[process.env.ENV_CONFIG]
const EXPORT_BASE_URL = CONFIG_EXPORT_BASE_URL[process.env.ENV_CONFIG]

export {
    BASE_URL,
    LOGIN_OUT_URL,
    IMG_UPLOAD_URL,
    EXPORT_BASE_URL
}