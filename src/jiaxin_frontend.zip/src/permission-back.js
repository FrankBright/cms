import router from './router'
import store from './store'
import { Message } from 'element-ui'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getToken } from '@/utils/auth'

NProgress.configure({ showSpinner: false })

// permission judge function
function hasPermission(roles, permissionRoles) {
  if (roles.indexOf('admin') >= 0) return true
  if (!permissionRoles) return true
  return roles.some(role => permissionRoles.indexOf(role) >= 0)
}

router.beforeEach((to, from, next) => {
  NProgress.start();
  if (to.meta && to.meta.noNeedLogin) {
    next();
    NProgress.done();
  } else if (getToken()) { // 判断是否已经登录且前往的页面不是登录页
    if (store.getters.roles.length === 0) {
      store.dispatch('GetUserInfo').then(res => {
        const roles = res;
        store.dispatch('GenerateRoutes', { roles }).then(() => {
          router.addRoutes(store.getters.addRouters);
          next({ ...to, replace: true });
          NProgress.done();
        })
      }).catch((err) => {
        store.dispatch('FedLogOut').then(() => {
          Message.error(err || '登录状态已失效，请重新登录！')
          next({ path: '/login' });
          NProgress.done();
        })
      })
    } else {
      if (hasPermission(store.getters.roles, to.meta.roles)) {
        next();
        NProgress.done();
      } else {
        next({ path: '/401', replace: true, query: { noGoBack: true } });
        NProgress.done();
      }
    }
  } else {
    next(`/login?redirect=${to.path}`);
    NProgress.done();
  }
})

router.afterEach(() => {
  NProgress.done()
})