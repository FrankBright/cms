<template>
  <div class="info">
    <h3 class="page-title">
      <el-popover placement="right" v-model="visible" visible-arrow="true" width="300" trigger="manual">
        <span class="iconfont icon-tishi11 c-yellow mgr-10"></span>如需修改开票信息，请联系客户经理
        <span slot="reference">开票信息</span>
      </el-popover>
    </h3>
    <div class="bd">
      <p>
        <label>公司名称：</label>{{formData.mchName}}
      </p>
      <p>
        <label>纳税人识别号:</label>{{formData.taxNo}}
      </p>
      <p>
        <label>公司电话：</label>{{formData.phone}}
      </p>
      <p>
        <label>发票内容：</label>{{formData.taxNo}}
      </p>
      <p>
        <label>开户银行：</label>{{formData.bankName}}
      </p>
      <p>
        <label>银行账号：</label>{{formData.bankCardNo}}
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "example",
  components: {},
  data() {
    return {
      visible: false,
      formData:{}
    };
  },
  created() {
    this.queryInfo();
  },
  mounted() {
    setTimeout(() => {
      this.visible = true;
    }, 300);
  },
  methods: {
    queryInfo() {
      this.$http.get("/jiaxin-web/invoice/mchInfo.do", {}).then(({data}) => {
        this.formData=data;
      });
    }
  },
  watch: {}
};
</script>
<style lang="scss" scoped>
.c-yellow {
  color: #ffc836;
  margin-right: 10px;
}
.info {
  .bd {
    color: #666666;
    line-height: 3em;
    padding-top: 20px;
    label {
      font-weight: normal;
      color: #333;
      width: 120px;
      display: inline-block;
    }
  }
}
</style>
<style lang="scss">
</style>
