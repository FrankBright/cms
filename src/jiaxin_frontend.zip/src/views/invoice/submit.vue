<template>
  <div id="wrapper">
    <Title :titles="titles" activeIndex="2"/>
    <div class="adress">
      <h5>邮寄地址</h5>
      <p>
        <span>{{address.receiverName}}</span>
        <span>{{address.receiverPhone}}</span>
        <span>{{address.receiverAddress}}</span>
      </p>
      <el-button type="text" @click="dialogVisible2=true">选择其他地址</el-button>
    </div>
    <div class="flex">
      <h3 class="page-title">
        <el-popover
          placement="right"
          v-model="visible"
          visible-arrow="true"
          width="300"
          trigger="manual"
        >
          <span class="iconfont icon-tishi11 c-yellow mgr-10"></span>所有发票金额之和需与开票金额相同
          <span slot="reference">开票详情</span>
        </el-popover>
      </h3>
      <span>申请开票总金额：{{$route.params.totalAmount}}元</span>
    </div>
    <Invoice
      v-for="(item, index) in list"
      :ref="`invoice_${index}`"
      :formData="item"
      :key="index"
      :index="index"
      @delete="deleteOne"
    />
    <el-button
      :round="false"
      size="medium"
      icon="el-icon-plus"
      style="width:100%;"
      @click="list.push({...common})"
    >新增发票</el-button>

    <div class="button">
      <el-button size="medium" @click="$router.push('/invoice/application')">上一步</el-button>
      <el-button type="primary" size="medium" @click="onSubmit">提交申请</el-button>
    </div>

    <el-dialog title="发票申请信息" :visible.sync="dialogVisible1" width="680px">
      <div class="rechargeInfo">
        <div class="info">
          <p>开票总金额： {{$route.params.totalAmount}}元</p>
          <p>开票张数： {{list.length}}</p>
          <p>
            邮寄地址：
            <span>{{address.receiverName}}</span>
            <span>{{address.receiverPhone}}</span>
            <span>{{address.receiverAddress}}</span>
          </p>
        </div>
        <p class="m main-color">请确认开票信息无误，提交后不可再修改</p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible1=false">取消</el-button>
        <el-button type="primary" @click="onNext">确定</el-button>
      </span>
    </el-dialog>

    <el-dialog title="选择地址" :visible.sync="dialogVisible2" width="680px">
      <XTableComponent ref="tableList" url="/jiaxin-web/address/getAddressList.do" type="get">
        <template slot="table">
          <el-table-column prop="receiverName" label="收件人"></el-table-column>
          <el-table-column prop="receiverPhone" label="电话"></el-table-column>
          <el-table-column prop="receiverAddress" label="地址"></el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button type="text" @click="onSelect(scope.row)">选择</el-button>
            </template>
          </el-table-column>
        </template>
      </XTableComponent>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible2 = false">取消</el-button>
        <!-- <el-button type="primary" @click="onNext">确定</el-button> -->
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Title from "@/components/title.vue";
import Invoice from "./components/invoice.vue";
import XTableComponent from "@/components/FilterTable/XTableComponent";
export default {
  data() {
    return {
      queryListUrl: "",
      titles: ["选择开票金额", "填写开票信息"],
      list: [{}],
      dialogVisible1: false,
      dialogVisible2: false,
      address: {},
      common: {}, //公共开票信息
      visible: false
    };
  },
  components: {
    Title,
    Invoice,
    XTableComponent
  },
  methods: {
    deleteOne(index) {
      this.list.splice(index, 1);
    },
    getAdress() {
      //获取默认的地址
      this.$http.get("/jiaxin-web/address/getAddressList.do").then(res => {
        this.address =
          res.data.records.find(v => v.status.code == 1) || res.data.records[0];
      });
    },
    onSelect(res) {
      //选择地址
      this.address = res;
      this.dialogVisible2 = false;
    },
    getMchInfo() {
      //开票基本信息
      this.$http.get("/jiaxin-web/invoice/mchInfo.do").then(res => {
        let { taxNo, phone, bankName, address, mchName } = res.data;
        this.common = { taxNo, phone, bankName, address, title: mchName };
        this.list = [{ ...this.common }];
      });
    },
    onSubmit() {
      //验证表单  提交申请
      var isRes = true;
      this.list.map((v, i) => {
        this.$refs[`invoice_${i}`][0].submitForm(flag => {
          isRes = isRes && flag;
          if (i == this.list.length - 1 && isRes) {
            if (
              parseFloat(this.$route.params.totalAmount) ==
              this.list.reduce((a, b) => a + parseFloat(b.totalAmount), 0)
            ) {
              //验证完成
              this.dialogVisible1 = true;
            } else {
              this.$message({
                type: "error",
                message: "所有发票金额之和需与开票金额相同"
              });
            }
          }
        });
      });
    },
    onNext() {
      //确定开票
      var params = this.$route.params;
      this.$http
        .post("/jiaxin-web/invoice/apply.do", {
          totalAmount: params.totalAmount, //总金额
          rechargeTransIdList: params.rechargeTransIdList, //交易id 列表
          deliveryAddress: this.address, //地址
          invoiceDetails: this.list //发票列表
        })
        .then(res => {
          if (res.code == 0) {
            this.dialogVisible1 = false;
            this.$confirm(
              "开票申请已提交，我们预计会在3个工作日内开具好并寄出。",
              "提交成功",
              {
                showConfirmButton: false,
                cancelButtonText: "知道了",
                type: "success",
                center: true
              }
            )
              .then(() => {
                this.$router.push("/invoice/record");
              })
              .catch(() => {
                this.$router.push("/invoice/record");
              });
          } else {
            this.$message({
              type: "error",
              message: res.msg
            });
          }
        });
    }
  },
  mounted() {
    setTimeout(() => {
      this.visible = true;
    }, 500);
    if (
      !this.$route.params.rechargeTransIdList ||
      !this.$route.params.totalAmount
    ) {
      this.$router.push("/invoice/application");
    } else {
      this.getAdress();
      this.getMchInfo();
    }
  }
};
</script>

<style lang="scss" scoped>
.c-yellow {
  color: #ffc836;
  margin-right: 10px;
}
#wrapper {
  .des {
    background: #fffdf5;
    border: 1px solid #ffc836;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 40px;
    dt {
      line-height: 20px;
      font-size: 14px;
      margin-bottom: 6px;
      color: #333;
    }
    dd {
      line-height: 17px;
      color: #666;
      font-size: 12px;
      margin-bottom: 6px;
      margin-left: 0;
      a {
        color: #13a2c0;
        text-decoration: underline;
      }
    }
  }
  .adress {
    padding-bottom: 30px;
    border-bottom: 1px dotted #b4b4b4;
    margin-bottom: 35px;
    h5 {
      margin-bottom: 25px;
    }
    p {
      font-size: 14px;
      color: #4f4f4f;
      margin-bottom: 10px;
      span {
        margin-right: 16px;
      }
    }
    button {
      margin: 0;
    }
  }
  .flex {
    display: flex;
    justify-content: space-between;
    line-height: 35px;
    margin-bottom: 20px;
  }
  .button {
    margin-top: 70px;
  }
}

h5 {
  font-size: 18px;
  color: #333333;
  line-height: 25px;
  font-weight: normal;
}
.main-color {
  color: #13a2c0 !important;
}
.rechargeInfo {
  line-height: 32px;
  p {
    color: #646464;
  }
  .m {
    margin: 10px 0;
  }
  hr {
    margin-top: 6px;
  }
  .info {
    background-color: #f8f8f8;
    padding: 10px 20px;
  }
  .flex {
    margin-top: 10px;
    display: flex;
    label {
      display: inline-block;
      width: 100px;
      line-height: 32px;
    }
  }
}
</style>
