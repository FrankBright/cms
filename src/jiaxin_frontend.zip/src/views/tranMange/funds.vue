<template>
  <div class="funds" v-if="info">
    <h3 class="page-title">账户信息</h3>
    <div class="account">
      <img :src="accountImg">
      <dl>
        <dt>账户总金额（元）</dt>
        <dd>{{info.depositBalance.toFixed(2)}}</dd>
      </dl>
      <span class="line"></span>
      <dl>
        <dt>可用金额（元）</dt>
        <dd>{{info.availBalance.toFixed(2)}}</dd>
      </dl>
    </div>
    <h3 class="page-title">充值信息</h3>
    <div class="pay-info">
      <p>付款账户名：{{info.accountName}}</p>
      <p>付款账户号：{{info.accountNo}}</p>
      <p>付款开户行：{{info.bankName}}</p>
    </div>
    <div class="me-info">
      <h3>请将充值金额从付款账户汇到以下账户，以完成充值。</h3>
      <div class="bd">
        <p>
          账户名：
          <span>{{info.recvAccountName}}</span>
        </p>
        <p>
          开户行：
          <span>{{info.recvBankName}}</span>
        </p>
        <p>
          账户号：
          <span>{{info.recvAccountNo}}</span>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "example",
  components: {},
  data() {
    return {
      accountImg: require("@/assets/images/account-02.png"),
      info: null
    };
  },
  created() {
    this.queryInfo();
  },
  mounted() {},
  methods: {
    queryInfo() {
      this.$http.get("/jiaxin-web/fundAccount/baseInfo.do", {}).then(res => {
        this.info = res.data;
      });
    }
  },
  watch: {}
};
</script>
<style lang="scss" scoped>
.funds {
  .account {
    display: flex;
    align-items: stretch;
    padding: 30px 0;
    & > * {
      margin-right: 25px;
      text-align: left;
    }
    dl {
      line-height: 2.1em;
      dt {
        color: #666;
      }
      dd {
        color: #13a2c0;
        text-align: left;
        font-size: 22px;
      }
    }
    .line {
      border-left: 1px solid #e2e2e2;
      margin-top: 3px;
      margin-bottom: 3px;
    }
  }
  .pay-info {
    color: #666;
    line-height: 2.2em;
    border-bottom: #e2e2e2 1px solid;
    padding-bottom: 20px;
  }
  .me-info {
    color: #666;
    line-height: 2.2em;
    margin-top: 20px;
    h3 {
      color: #13a2c0;
      font-weight: normal;
      font-size: 14px;
      margin-bottom: 10px;
    }
    .bd {
      background: #f8f8f8;
      padding: 20px;
      span {
        color: #333;
      }
    }
  }
}
</style>