<template>
    <el-form-item :label="label" :prop="name" v-bind="$attrs">
        <el-select v-model="val" @change="updateValue" v-bind="$attrs">
            <el-option v-for="(item,i) in options" :key="i" :label="item.label" :value="item.value"></el-option>
        </el-select>
    </el-form-item>
</template>

<script>
export default {
  data() {
    return {
      val: this.value,
      options: []
    };
  },
  props: [//value,label为配置参数的固定格式，可修改
    "url",//请求url
    "label",
    "name",
    "value",
    "queryData",//请求附带参数值
    "queryKey",//请求参数key
    "optionsData"//数据非Url请求
  ],
  watch: {
    value() {
      this.val = this.value;
    },
    queryData() {
      this.val = "";
      if (this.queryData[0] != undefined) {
        this.getOptions();
      } else {
        this.options = [];
      }
    }
  },
  methods: {
    updateValue(val) {
      this.$emit("input", val);
    },
    getOptions() {
      if (this.url) {
        let params = {};
        if (this.queryData) {
          params = {
            [this.queryKey]: this.queryData[this.queryData.length - 1]
          };
        }
        if (!(this.queryKey && !this.queryData)) {
          this.$http.get(this.url, params).then(res => {
            this.options = res.data;
          });
        }
      }
    }
  },
  mounted() {
    // console.log(this.optionsData)
    if (!this.optionsData) {
      this.getOptions();
    } else {
      this.options = this.optionsData;
    }
  }
};
</script>
<style lang="scss">
</style>