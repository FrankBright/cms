module.exports = {
  // 测试环境
  NODE_ENV: '"production"',
  ENV_CONFIG: '"sit"',
  BASE_API: '"/"',
}