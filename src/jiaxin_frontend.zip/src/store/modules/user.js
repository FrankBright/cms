import request from '@/utils/request'
import { getToken, setToken } from '@/utils/auth'

const user = {
  state: {
    token: getToken(),
    userInfo: sessionStorage.getItem('userInfo'),
    userName: sessionStorage.getItem('userName'),
    roles: []
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      setToken(token);
      state.token = token;
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles;
    },
    SET_USERNAME: (state, userName) => {
      sessionStorage.setItem('userName', userName);
      state.userName = userName;
    },
    SET_USERINFO: (state, userInfo) => {
      sessionStorage.setItem('userInfo', userInfo);
      state.userInfo = userInfo;
    }
  },
  actions: {
    // 获取用户信息
    GetUserInfo({ commit, state }) {
      return new Promise((resolve, reject) => {
        commit('SET_ROLES', ['admin']);
        resolve(['admin']);
        // request.post('/user/info').then(response => {
        //   const result = response.data;
        //   let roles = result.data.menuList;
        //   commit('SET_ROLES', roles);
        //   resolve(state.roles);
        // }, () => {
        //   removeToken();
        //   resolve([]);
        // }).catch(error => {
        //   console.log(error);
        //   reject(error)
        // });
      });
    },
    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        request.get('/jiaxin-web/login/merchantLogout.do').then(() => {
          commit('SET_TOKEN', '');
          commit('SET_ROLES', []);
          resolve();
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '');
        commit('SET_ROLES', []);
        resolve();
      })
    }
  }
}

export default user
