<template>
  <div id="wrapper">
    <Title :titles="titles" activeIndex="3"/>
    <div class="tip">
      <div>
        <label for>计划打款金额（元）：</label>
        <span>{{info.sumSalaryAmount}}</span>
        <label for>计划服务费（元）：</label>
        <span>{{info.sumFeeAmount}}</span>
      </div>
      <div>
        <label for>实际打款金额（元）：</label>
        <span>{{info.sumPaidSalaryAmount}}</span>
        <label for>待打款金额（元）：</label>
        <span>{{info.sumUnPaidSalaryAmount}}</span>
      </div>
    </div>
    <div>
      <CountDown :endTime="info.expiredTime" :msgTime="info.finishedTime" v-if="info.expiredTime">
        <template
          slot="initct"
          slot-scope="slotProps"
        >需收款人签约完成才能对该收款人打款，该批签约时效性还剩 <font color="#FF7F22">{{ slotProps.time}}</font></template>
        <template slot="endct" slot-scope="slotProps">需收款人签约完成才能对该收款人打款，该批签约于 <font color="#FF7F22">{{ slotProps.endTime}}</font> 结束</template>
      </CountDown>
    </div>
    <div class="clearfix list">
      <el-button style="float:right;" icon="el-icon-download" @click="download">下载列表</el-button>
    </div>

    <XTableComponent ref="tableList" :url="queryListUrl" :filterData="filterData">
      <template slot="table">
        <el-table-column prop="platformId" label="平台id"></el-table-column>
        <el-table-column prop="userName" label="姓名"></el-table-column>
        <el-table-column prop="userMobile" label="手机号"></el-table-column>
        <el-table-column prop="userIdCardNo" label="身份证号"></el-table-column>
        <el-table-column prop="userBankCardNo" label="银行账号"></el-table-column>
        <el-table-column prop="salaryAmount" label="打款金额(元)"></el-table-column>
        <el-table-column prop="signStatus" label="签约状态">
          <template slot-scope="scope">{{scope.row.signStatus.desc}}</template>
        </el-table-column>
        <el-table-column prop="orderNo" label="订单流水号"></el-table-column>
        <el-table-column prop="status" label="订单状态">
          <template slot-scope="scope">{{scope.row.status.desc}}</template>
        </el-table-column>
      </template>
    </XTableComponent>
  </div>
</template>

<script>
import Title from "@/components/title.vue";
import XTableComponent from "@/components/FilterTable/XTableComponent";
import CountDown from "@/components/CountDown/index";
export default {
  data() {
    return {
      titles: ["上传打款文件", "核对打款信息", "开始打款"],
      filterData: {
        batchNo: ""
      },
      queryListUrl: "/jiaxin-web/order/getOrders.do",
      info: {}
    };
  },
  components: {
    Title,
    CountDown,
    XTableComponent //表格组件
  },
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    getInfo() {
      this.$http
        .post("/jiaxin-web/order/getBatchs.do", {
          batchNo: this.$route.query.batchNo,
          current: 1,
          size: 10
        })
        .then(res => {
          this.info = res.data.records[0];
          // this.info.expiredTime="2019-06-11 16:57:52"
        });
    },
    download() {
      window.open(
        "/jiaxin-web/order/exportOrders.do?batchNo=" + this.$route.query.batchNo
      );
    }
  },
  mounted() {
    this.filterData.batchNo = this.$route.query.batchNo;
    this.getInfo();
  }
};
</script>

<style lang="scss" scoped>
#wrapper {
  .tip {
    background: #f8f8f8;
    padding: 0 18px;
    font-size: 14px;
    margin-bottom: 20px;
    line-height: 20px;
    overflow: hidden;
    div {
      margin: 24px 0;
      label {
        display: inline-block;
        font-weight: normal;
        color: #666;
      }
      span {
        display: inline-block;
        width: 200px;
        color: #333;
      }
    }
  }
  .list {
    margin-top: 10px;
    margin-bottom: 30px;
  }
}
</style>
