<template>
  <el-form
    size="small"
    class="form"
    ref="form"
    :model="formData"
    label-position="left"
    label-width="100px"
  >
    <div class="delete" @click="deleteOne" v-if="index!=0 && type!='detail'">
      <i class="iconfont icon-shanchu"></i> 删除
    </div>
    <XSelectCompoent
      v-if="type!='detail'"
      label="发票类型"
      :clearable="true"
      name="type"
      url="/jiaxin-web/common/dataDic.do?dataTypeNo=1005"
      v-model="formData.type"
      :rules="[
      { required: true, message: '请选择发票类型'},
    ]"
    ></XSelectCompoent>
    <el-form-item
      v-else
      label="发票类型"
      :rules="[
      { required: true, message: '请选择发票内容'},
    ]"
    >{{formData.type.desc}}</el-form-item>
    <div class="flex">
      <div class="el-form-item is-required" style="width:40%; display:inline-block;">
        <label class="el-form-item__label">发票抬头：</label>
        <div class="el-form-item__content" style="margin-left: 100px;">{{formData.title}}</div>
      </div>
      <div class="el-form-item is-required" style="width:40%; display:inline-block;">
        <label class="el-form-item__label">纳税人识别号：</label>
        <div class="el-form-item__content" style="margin-left: 100px;">{{formData.taxNo}}</div>
      </div>
    </div>
    <div class="flex" v-if="formData.type && (formData.type == 1 || formData.type.code == 1)">
      <div class="el-form-item is-required" style="width:40%; display:inline-block;">
        <label class="el-form-item__label">地址、电话：</label>
        <div
          class="el-form-item__content"
          style="margin-left: 100px;"
        >{{`${formData.address}-${formData.phone}`}}</div>
      </div>
      <div class="el-form-item is-required" style="width:40%; display:inline-block;">
        <label class="el-form-item__label">开户行及账号：</label>
        <div class="el-form-item__content" style="margin-left: 100px;">{{formData.bankName}}</div>
      </div>
    </div>
    <XSelectCompoent
      label="发票内容"
      v-if="type!='detail'"
      :clearable="true"
      name="content"
      url="/jiaxin-web/common/dataDic.do?dataTypeNo=1006"
      v-model="formData.content"
      :rules="[
      { required: true, message: '请选择发票内容'},
    ]"
    ></XSelectCompoent>
    <el-form-item
      v-else
      label="发票内容"
      :rules="[
      { required: true, message: '请选择发票内容'},
    ]"
    >{{formData.content.desc}}</el-form-item>
    <el-form-item
      label="发票金额"
      style="width:40%;"
      prop="totalAmount"
      :rules="[
      { required: true, message: '请输入发票金额'},
    ]"
    >
      <el-input
        type="number"
        v-model="formData.totalAmount"
        placeholder="请输入发票金额"
        :disabled="type=='detail'"
      ></el-input>
    </el-form-item>
    <el-form-item
      label="备注"
      style="width:40%;"
      prop="remark"
    >
      <el-input
        type="textarea"
        v-model="formData.remark"
        :placeholder="type=='detail' ? '' : '此处内容会填写在发票备注栏中，请确认后填写'"
        :disabled="type=='detail'"
      ></el-input>
    </el-form-item>
  </el-form>
</template>

<script>
import { MessageBox } from "element-ui";
import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
export default {
  props: ["formData", "index", "type"],
  data() {
    return {};
  },
  components: {
    XSelectCompoent
  },
  methods: {
    submitForm(callback) {
      this.$refs.form.validate(valid => {
        if (valid) {
          callback(true);
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    deleteOne() {
      MessageBox.confirm("是否删除?", {
        type: "warning"
      }).then(() => {
        this.$emit("delete", this.index);
      });
    }
  },
  mounted() {}
};
</script>

<style lang="scss" scoped>
.form {
  background: #f8f8f8;
  margin-bottom: 20px;
  padding: 20px;
  position: relative;
  .delete {
    position: absolute;
    top: 20px;
    right: 20px;
    color: #666;
    font-size: 16px;
    cursor: pointer;
    z-index: 100;
  }
  .flex {
    display: flex;
    justify-content: space-between;
  }
}
</style>




