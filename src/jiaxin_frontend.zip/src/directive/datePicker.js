
function setData(obj, exp, val) {
    let expArray = exp.split('.');
    while (expArray.length > 1) {
        obj = obj[expArray.shift()];
    }
    obj[expArray.shift()] = val;
}
export default {
    install: Vue => {
        Vue.directive('starttime', {
            bind(el, binding, vnode) {
                const modelExpression = vnode.data.model.expression;
                if (vnode.data.directives[0]) {
                    const modelVal = [new Date(vnode.data.directives[0].value), new Date(vnode.data.directives[1].value)];
                    setData(vnode.context._data, modelExpression, modelVal);
                }
                // vnode.data.model.value=modelVal; 没有效果
            },
            update(el, { expression }, vnode) {
                let modelVal = vnode.data.model.value  && vnode.data.model.value[0] || '';
                setData(vnode.context._data, expression, modelVal);
            }
        });
        Vue.directive('endtime', {
            bind(el, binding, vnode) {
            },
            update(el, { expression }, vnode) {
                let modelVal = vnode.data.model.value && vnode.data.model.value[1] || '';
                setData(vnode.context._data, expression, modelVal);
            }
        });
    }
}