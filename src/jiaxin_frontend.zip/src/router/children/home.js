import Main from "@/views/layout/main";

const routes = [{
    path: '/home',
    component: Main,
    redirect: '/home/index',
    name: 'home',
    meta: {
        title: '首页',
        icon: 'icon-houtaiguanlizhuye',
        // roles: ['']
    },
    children: [
        {
            path: '/home/index',
            component: () => import('@/views/home/index'),
            name: 'home2',
            meta: { title: '首页', roles: ['admin'], nav: 'home' }
        },
    ]
}]

export default {
    name: 'home',
    routes: routes,
    title: '首页',
    icon: 'icon2',
    // defaultUrl: '/tranMange/theDetail',
    roles: ['admin']
}