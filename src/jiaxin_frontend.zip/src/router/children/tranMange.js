import Layout from '@/views/layout/Layout'

const routes = [
    {
        path: '/account',
        component: Layout,
        redirect: '/account/funds',
        name: 'account',
        meta: {
            title: '账户资金',
            icon: 'icon-lipinqiaguanli',
            nav: 'tranMange',
            // roles: ['']
        },
        children: [{
            path: 'funds',
            component: () => import('@/views/tranMange/funds.vue'),
            name: 'funds',
            meta: {
                title: '账户资金',
                icon: 'icon-lipinqiaguanli',
                nav: 'tranMange',
                // roles: ['home']
            }

        }]
    },
    {
        path: '/batch',
        component: Layout,
        redirect: '/batch/batchPayment',
        name: 'batch',
        meta: {
            title: '批量打款',
            icon: 'icon-lipinqiaguanli',
            nav: 'tranMange',
            // roles: ['']
        },
        children: [{
            path: 'batchPayment',
            component: () => import('@/views/tranMange/batchPayment.vue'),
            name: 'batchPayment',
            meta: {
                title: '批量打款',
                icon: 'icon-lipinqiaguanli',
                nav: 'tranMange',
                // roles: ['home']
            }

        },{
            path: 'checkPayment',
            component: () => import('@/views/tranMange/checkPayment.vue'),
            name: 'checkPayment',
            hidden: true,
            meta: {
                title: '核对打款信息',
                nav: 'tranMange',
                // roles: ['home']
            }

        },{
            path: 'startPayment',
            component: () => import('@/views/tranMange/startPayment.vue'),
            name: 'startPayment',
            hidden: true,
            meta: {
                title: '开始打款',
                nav: 'tranMange',
                // roles: ['home']
            }

        }]
    },
    {
        path: '/payrecord',
        component: Layout,
        redirect: '/payrecord/batchPaymentRecord',
        name: 'payrecord',
        meta: {
            title: '批量打款记录',
            icon: 'icon-lipinqiaguanli',
            nav: 'tranMange',
            // roles: ['']
        },
        children: [{
            path: 'batchPaymentRecord',
            component: () => import('@/views/tranMange/batchPaymentRecord.vue'),
            name: 'batchPaymentRecord',
            meta: {
                title: '批量打款记录',
                icon: 'icon-lipinqiaguanli',
                nav: 'tranMange',
                // roles: ['home']
            }

        }]
    },
    {
        path: '/tranRecord',
        component: Layout,
        redirect: '/tranRecord/rechargeRecord',
        name: 'tranRecord',
        meta: {
            title: '交易记录',
            icon: 'icon-lipinqiaguanli',
            // roles: ['']
        },
        children: [
            {
                path: 'rechargeRecord',
                component: () => import('@/views/tranMange/rechargeRecord.vue'),
                name: 'rechargeRecord',
                meta: {
                    title: '充值记录',
                    nav: 'tranMange',
                    // roles: ['home']
                }

            },
            {
                path: 'paymentRecord',
                component: () => import('@/views/tranMange/paymentRecord.vue'),
                name: 'paymentRecord',
                meta: {
                    title: '打款记录',
                    nav: 'tranMange',
                    // roles: ['home']
                }
            },
            // {
            //     path: 'test',
            //     component: () => import('@/views/test/index.vue'),
            //     name: 'test',
            //     meta: {
            //         title: '测试页面',
            //         nav: 'tranMange',
            //         // roles: ['home']
            //     }
            // }
        ]
    }
]

export default {
    name: 'tranMange',
    routes: routes,
    title: '交易管理',
    icon: 'icon2',
    // defaultUrl: '/tranMange/theDetail',
    roles: ['admin']
}