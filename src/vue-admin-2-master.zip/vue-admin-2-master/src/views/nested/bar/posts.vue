<template>
  <div style="margin-top:30px;">
    <el-alert title="Children: Posts" type="warning" :closable="false">
    </el-alert>
  </div>
</template>
