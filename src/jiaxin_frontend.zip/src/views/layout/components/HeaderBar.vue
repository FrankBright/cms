<template>
<div class='headerbox'> 
  <ul class="headerBar">
      <router-link class="title" to="/home"><img :src="require('@/assets/images/logo.png')" alt=""></router-link>
      <router-link v-for="(val, key, i) in asyncRouterMap" :key="i" tag="li" :to="val.routes[0].path" :class="{'active': val.name == currentNav}">{{val.title}}</router-link>
      <Navbar></Navbar>
  </ul>
</div>
</template>
<script>
import { asyncRouterMap } from "@/router";
import { mapGetters } from "vuex";
import Navbar from "./Navbar";
export default {
  name: "headerBar",
  components: {
    Navbar
  },
  data() {
    return {
      asyncRouterMap: asyncRouterMap
    };
  },
  methods: {},
  computed: {
    ...mapGetters(["currentNav"])
  }
};
</script>
<style lang="scss" scoped>
.headerbox{
  background: #25272A;
  height: 60px;
}
.headerBar {
  max-width: 1380px;
  margin: 0 auto;
  line-height: 60px;
  padding-left: 40px;
  .title {
    text-align: center;
    display: inline-block;
    vertical-align: top;
    font-size: 0;
    margin-right: 90px;
    img{
      vertical-align: middle;
    }
  }
  li {
    list-style: none;
    display: inline-block;
    font-size: 16px;
    color: #ffffff;
    letter-spacing: 0;
    padding: 0 36px;
    cursor: pointer;
    color: rgba(255, 255, 255, 0.7);
    &.active {
      color:#fff;
    }
  }
  .navbar {
    display: inline-block;
    float: right;
    margin: 5px 0 0 0;
  }
}
</style>