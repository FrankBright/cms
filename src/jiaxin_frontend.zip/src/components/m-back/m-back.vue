<template>
    <div class='m-back'>
        <a>
            <i class="el-icon-arrow-left"
               @click="jump">
                <div class="slot">
                    <slot></slot>
                </div>
            </i>

        </a>
    </div>
</template>

<script>
export default {
  props: {
    path: ""
  },
  methods: {
    jump() {
      this.path ? this.$router.push(this.path) : this.$router.go(-1);
    }
  }
};
</script>

<style lang='scss' scoped>
.m-back {
  display: inline-block;
  font-size: 1.125rem;
  .slot {
    display: inline-block;
    margin-left: 0.625rem;
  }
}
</style >
