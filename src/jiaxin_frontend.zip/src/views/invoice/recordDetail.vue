<template>
  <div class="recordDetail">
    <h3 class="page-title">基本信息</h3>
    <!-- 过滤表单 start-->
    <div class="info">
      <p>
        <label>发票申请编号：</label>
        {{info.batchNo}}
      </p>
      <p>
        <label>申请时间：</label>
        {{info.createdTime}}
      </p>
      <p>
        <label>状态：</label>
        {{info.status.desc}}
      </p>
      <p>
        <label>物流单号：</label>
        {{info.deliveryNo}}
      </p>
      <p>
        <label>邮寄地址：</label>
        <span>{{info.deliveryAddress.receiverName}}</span>
        <span>{{info.deliveryAddress.receiverPhone}}</span>
        <span>{{info.deliveryAddress.receiverAddress}}</span>
      </p>
      <p>
        <label>开票总金额：</label>
        {{info.totalAmount}}元
      </p>
    </div>
    <div class="list">
      <h3 class="page-title">开票详情</h3>
      <div class="bd">
        <Invoice
          type="detail"
          v-for="(item, index) in info.invoiceDetails"
          :ref="`invoice_${index}`"
          :formData="item"
          :key="index"
          :index="index"
          @delete="deleteOne"
        />
      </div>
    </div>
  </div>
</template>

<script>
import Invoice from "./components/invoice.vue";
export default {
  name: "example",
  components: { Invoice },
  data() {
    return {
      info: {
        status: {},
        deliveryAddress: {},
        invoiceDetails: []
      }
    };
  },
  created() {
    this.queryRecordDetail();
  },
  mounted() {},
  methods: {
    queryRecordDetail() {
      this.$http
        .get("/jiaxin-web/invoice/invoiceBatchDetail.do", {
          batchNo: this.$route.query.batchNo
        })
        .then(({ data }) => {
          this.info = data;
        });
    }
  },
  watch: {}
};
</script>
<style lang="scss" scoped>
.recordDetail {
  .info {
    line-height: 3em;
    color: #666;
    label {
      font-weight: normal;
      width: 8em;
      display: inline-block;
      color: #333;
    }
  }
  .list {
    margin-top: 40px;
  }
}
</style>