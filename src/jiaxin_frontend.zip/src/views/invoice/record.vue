<template>
  <div class="record">
    <h3 class="page-title">开票记录</h3>
    <!-- 过滤表单 start-->
    <XFilterComponent @submit="filterQuery" :formData="filterData" :rules="rules" btnToTop>
      <!-- 下单时间 -->
       <el-form-item label="发票申请编号" prop="batchNo">
        <el-input v-model="filterData.batchNo" placeholder="发票申请编号"></el-input>
      </el-form-item>
      <el-form-item label="申请时间" prop="date" style="width:50%">
        <el-date-picker
          v-model="filterData.date"
          type="datetimerange"
          range-separator="至"
          :default-time="['00:00:00', '23:59:59']"
          value-format="yyyy-MM-dd HH:mm:ss"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
    </XFilterComponent>
    <!-- 过滤表单 end-->
    <!-- 表格 start-->
    <XTableComponent ref="tableList" :url="queryListUrl" :filterData="filterData">
      <template slot="table">
        <el-table-column prop="batchNo" label="流水号"></el-table-column>
        <el-table-column prop="createdTime" label="入账时间"></el-table-column>
        <el-table-column prop="totalAmount" label="计税合计总额（元）">
          <template slot-scope="scope">{{scope.row.totalAmount&&scope.row.totalAmount.toFixed(2)}}</template>
        </el-table-column>
        <el-table-column prop="quantity" label="申请发票数"></el-table-column>
        <el-table-column prop="status.desc" label="状态"></el-table-column>
        <el-table-column prop="payerCnyShortName" label="操作">
           <template slot-scope="scope">
            <span @click="readDetail(scope.row)" class="read-detail">查看</span>
          </template>
        </el-table-column>
      </template>
    </XTableComponent>
    <!-- 表格 end-->
  </div>
</template>

<script>
import XFilterComponent from "@/components/FilterTable/XFilterComponent";
import XTableComponent from "@/components/FilterTable/XTableComponent";
import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
export default {
  name: "example",
  components: {
    XFilterComponent, //过滤表单组件
    XTableComponent, //表格组件
    XSelectCompoent //下拉二次封装
  },
  data() {
    return {
      //-----------------列表查询模型必要配置start
      filterData: {
        //过滤条件数据，所有查询字段需实现定义
        date: ['',''], //时间范围默认是前端控件是数组类型，不符合接口类型，需进行watch进行分别赋值，建议后端更改接口类型最为合适
        batchNo:''
      },
      rules: {
        //过滤提交校验、非必填:样例如下
        // userName: [
        //   { required: true, message: "请输入用户名", trigger: "blur" },
        //   { min: 1, max: 7, message: "长度在 1 到 7 个字符", trigger: "blur" }
        // ]
      },
      queryListUrl: "/jiaxin-web/invoice/invoiceList.do" //列表查询url
      // formatFilterData:null, 过滤数据不能直接使用，启用该方式
      //-----------------列表查询模型必要配置end
    };
  },
  created() {},
  mounted() {},
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    readDetail({batchNo}) {
      this.$router.push({
        name:'recordDetail',
        query:{
          batchNo: batchNo
        }
      });
    }
  },
  watch: {
    
  }
};
</script>
<style lang="scss" scoped>
.record {
  .read-detail{
    color: #13A2C0;
    cursor: pointer;
  }
}
</style>