import home from "./children/home.js";
import tranMange from "./children/tranMange.js";
import finance from "./children/finance.js";

export const asyncRouterMap = [
    home, //首页
    tranMange,//交易管理
    finance,//财务管理
]