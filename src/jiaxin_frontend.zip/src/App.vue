<template>
  <div id="app">
        <router-view></router-view>
  </div>
</template>

<script>
  export default{
    name: 'App'
  }
</script>

<style lang="scss">
body{
  background-color: #f7f7f9;
  .layout-wrapper{
    max-width: 1380px;
    min-width: 1200px;
    margin: 0 auto;
    position: relative;
  }
}
</style>

