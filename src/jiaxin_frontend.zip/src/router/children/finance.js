import Layout from '@/views/layout/Layout'

const routes = [
    {
        path: '/invoice',
        component: Layout,
        redirect: '/invoice/application',
        name: 'invoice',
        meta: {
            title: '开票管理',
            icon: 'icon-lipinqiaguanli',
            nav:'finance'
            // roles: ['']
        },
        children: [
            {
                path: 'application',
                component: () => import('@/views/invoice/application.vue'),
                name: 'application',
                meta: {
                    title: '开票申请',
                    nav: 'finance',
                    // roles: ['home']
                }
            },
            {
                path: 'submit',
                component: () => import('@/views/invoice/submit.vue'),
                name: 'submit',
                hidden: true,
                meta: {
                    title: '填写开票信息',
                    nav: 'finance',
                    // roles: ['home']
                }

            },
            {
                path: 'record',
                component: () => import('@/views/invoice/record.vue'),
                name: 'record',
                meta: {
                    title: '开票记录',
                    nav: 'finance',
                    // roles: ['home']
                }
            },
            {
                path: 'recordDetail',
                component: () => import('@/views/invoice/recordDetail.vue'),
                name: 'recordDetail',
                hidden: true,
                meta: {
                    title: '开票记录',
                    nav: 'finance',
                    // roles: ['home']
                }
            },
            {
                path: 'info',
                component: () => import('@/views/invoice/info.vue'),
                name: 'info',
                meta: {
                    title: '开票信息',
                    nav: 'finance',
                    // roles: ['home']
                }
            },
            {
                path: 'address',
                component: () => import('@/views/invoice/address.vue'),
                name: 'address',
                meta: {
                    title: '邮寄地址',
                    nav: 'finance',
                    // roles: ['home']
                }
            }
        ]
    }
]

export default {
    name: 'finance',
    routes: routes,
    title: '财务管理',
    icon: 'icon2',
    // defaultUrl: '/tranMange/theDetail',
    roles: ['admin']
}