<template>
  <div class="app-wrapper" id="main">
    <HeaderBar></HeaderBar>
    <div class="home-main">
      <!-- <tags-view></tags-view> -->
      <app-main></app-main>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain, TagsView, HeaderBar } from "./components";
export default {
  name: "mainPage",
  components: {
    HeaderBar,
    AppMain
  },
  data() {
    return {};
  },
  created() {},
  mounted() {},
  computed: {},
  methods: {}
};
</script>
<style lang="scss" scoped>
@import "src/styles/mixin.scss";
.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
  overflow: hidden;
  .home-main{
      box-sizing: border-box;
      height: 100%;
      overflow-y: auto;
      padding-bottom: 60px;
  }
}
</style>

