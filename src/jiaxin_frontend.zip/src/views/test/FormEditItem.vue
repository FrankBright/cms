<template>
  <el-form-item :label="label+'：'" :prop="prop" v-bind="$attrs" class="form-item">
    <!-- 新增 -->
    <slot name="add" v-if="(type==0&&$slots.add)||(type==1&&$slots.add)"></slot>
    <template v-if="type==0&&!$slots.add">{{parentData[prop]}}</template>
    <!-- 编辑 -->
    <slot name="edit" v-if="type==1&&$slots.edit"></slot>
    <!-- <template v-if="type==1&&!$slots.edit">{{parentData[prop]}}</template> -->
    <!-- 详情 -->
    <slot name="detail" v-if="type==2&&$slots.detail"></slot>
    <template v-if="type==2&&!$slots.detail">{{parentData[prop]}}</template>
  </el-form-item>
</template>

<script>
export default {
  props: ["label", "prop"],
  data() {
    return {
      type: 0,
      slots: null
    };
  },
  methods: {},
  mounted() {},
  computed: {
    parentData() {
      return this.$parent.model;
    }
  },
  created() {
    this.type = this.$parent.$attrs.type;
  }
};
</script>

<style lang='scss'>
.form-edit {
  .el-input {
    width: inherit;
  }
  .unit {
    margin: 0 10px;
  }
  .el-upload-list {
    &.is-disabled {
      & + .el-upload {
        display: none;
      }
    }
  }
}
</style >
