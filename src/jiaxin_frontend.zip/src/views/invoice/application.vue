<template>
  <div id="wrapper">
    <Title :titles="titles" activeIndex="1"/>
    <dl class="des">
      <dt>发票说明：</dt>
      <dd>1. 发票申请时间：自订单完成日起7天后可申请开具发票。</dd>
      <dd>2. 发票开具时间：自申请之日起1周内开具，纸质发票会在开具完成后当日寄出，3-5个工作日即可邮寄到贵司</dd>
      <dd>3. 申请增值税专用发票，开票金额合计超1000元给予开票，如果一季度还未超1000元，可以按季度开。</dd>
    </dl>
    <XTableComponent
      ref="multipleTable"
      :url="queryListUrl"
      :filterData="filterData"
      @selection-change="onSelect"
    >
      <template slot="table">
        <el-table-column label="全选" type="selection"></el-table-column>
        <el-table-column label="流水号" prop="transId"></el-table-column>
        <el-table-column prop="transDate" label="入账时间"></el-table-column>
        <el-table-column prop="amount" label="金额（元）">
          <template slot-scope="scope">{{scope.row.amount&&scope.row.amount.toFixed(2)}}</template>
        </el-table-column>
        <el-table-column prop="actualAmount" label="实际到账金额（元）">
          <template slot-scope="scope">{{scope.row.actualAmount&&scope.row.actualAmount.toFixed(2)}}</template>
        </el-table-column>
      </template>
    </XTableComponent>
    <!-- <el-table
      ref="multipleTable"
      :data="list"
      tooltip-effect="dark"
      header-align="center"
      style="width: 100%"
      :header-cell-style="{background: '#f4f4f4',color:'#333', 'text-align':'center'}"
      @selection-change="onSelect"
    ></el-table>-->
    <div class="count">
      <span>
        已选中：
        <span class="main-color">{{result.length}}条</span>
      </span>
      <span>
        共可开票金额：
        <span class="main-color">{{total}}元</span>
      </span>
    </div>
    <div>
      <el-button size="medium" @click="$refs.multipleTable.clearSelection()">清除</el-button>
      <el-button type="primary" size="medium" :disabled="result.length == 0" @click="next">下一步</el-button>
    </div>
  </div>
</template>

<script>
import Title from "@/components/title.vue";
import XTableComponent from "@/components/FilterTable/XTableComponent";
export default {
  data() {
    return {
      titles: ["选择开票金额", "填写开票信息"],
      list: [{}, {}],
      result: [],
      filterData: {
        current: 1,
        size: 10
      },
      queryListUrl: "/jiaxin-web/recharge/getMerchantRechargeDetail.do"
    };
  },
  components: { Title, XTableComponent },
  computed: {
    total() {
      return this.result.reduce((a, b) => a + b.amount, 0).toFixed(2);
    }
  },
  methods: {
    onSelect(result) {
      this.result = result;
    },
    next() {
      this.$router.push({
        name: "submit",
        params: {
          totalAmount: this.total,
          rechargeTransIdList: this.result.map(v => v.transId)
        }
      });
    }
  },
  mounted() {}
};
</script>

<style lang="scss" scoped>
#wrapper {
  .des {
    background: #fffdf5;
    border: 1px solid #ffc836;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 40px;
    dt {
      line-height: 20px;
      font-size: 14px;
      margin-bottom: 6px;
      color: #333;
    }
    dd {
      line-height: 17px;
      color: #666;
      font-size: 12px;
      margin-bottom: 6px;
      margin-left: 0;
      a {
        color: #13a2c0;
        text-decoration: underline;
      }
    }
  }
  div.count {
    margin-top: 60px;
    font-size: 16px;
    line-height: 22px;
    margin-bottom: 90px;
    > span {
      margin-right: 25px;
    }
  }
}

.main-color {
  color: #13a2c0;
}
</style>
