<template>
  <div class="thedetail">
    <FormEditCom :props="formConfig" v-model="formData" :type="type" :rules="rules">
      <FormEditItem prop="username" label="姓名">
        <template slot="add">
          <el-input v-model="formData.username" placeholder="请输入内容" :disabled="type==1"></el-input>
          <span class="unit">元</span>
        </template>
        <!-- <template slot="edit">
          <el-input v-model="formData.username" disabled="true" placeholder="请输入内容"></el-input>
        </template>-->
        <!-- <template slot="detail">{{formData.username}}</template> -->
      </FormEditItem>
      <FormEditItem prop="region" label="活动区域">
        <template slot="add">
          <el-select v-model="formData.region" placeholder="请选择活动区域">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </template>
      </FormEditItem>
      <FormEditItem prop="region" label="活动区域">
        <template slot="add">
          <el-date-picker
            v-model="formData.requestTime"
            type="daterange"
            range-separator="至"
            value-format="yyyy-MM-dd HH:mm:ss"
            :default-time="['00:00:00', '23:59:59']"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
          ></el-date-picker>
        </template>
      </FormEditItem>
      <FormEditItem prop="fileList" label="图片">
        <template slot="add">
          <el-upload
            action="https://jsonplaceholder.typicode.com/posts/"
            list-type="picture-card"
            :file-list="formData.fileList"
          >
            <i class="el-icon-plus"></i>
          </el-upload>
        </template>
        <template slot="detail">
          <el-upload
            action="https://jsonplaceholder.typicode.com/posts/"
            list-type="picture-card"
            :file-list="formData.fileList"
            disabled
          >
            <i class="el-icon-plus"></i>
          </el-upload>
        </template>
      </FormEditItem>
    </FormEditCom>
  </div>
</template>

<script>
import FormEditCom from "./FormEditCom.vue";
import FormEditItem from "./FormEditItem.vue";
// import XFilterComponent from "@/components/FilterTable/XFilterComponent";
// import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
export default {
  name: "example",
  components: {
    FormEditCom,
    FormEditItem
    // XFilterComponent //过滤表单组件
    // XTableComponent, //表格组件
    // XSelectCompoent //下拉二次封装
  },
  data() {
    return {
      type: 0,
      formData: {
        username: "",
        region: "",
        requestTime: [],
        fileList: []
      },
      rules: {
        //过滤提交校验、非必填:样例如下
        username: [
          { required: true, message: "请输入活动名称", trigger: "blur" },
          { min: 3, max: 5, message: "长度在 3 到 5 个字符", trigger: "blur" }
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" }]
      },
      formConfig: {
        url: ["", "", ""]
      }

      // formatFilterData:null, 过滤数据不能直接使用，启用该方式
      //-----------------列表查询模型必要配置end
    };
  },
  created() {
    this.type = !this.$route.query.type ? 0 : this.$route.query.type;
  },
  mounted() {},
  updated() {},
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    viewDetail(row) {
      this.detailData = row;
      this.dialogVisible = true;
    }
  },
  watch: {}
};
</script>
<style lang="scss" scoped>
.lodingTable {
  border-spacing: 0;
  border-collapse: collapse;
  width: 100%;
  line-height: 20px;
  tr {
    td {
      text-align: center;
      border: 1px solid #e1e1e1;
      padding: 10px;
    }
    .th {
      border: 1px solid #e1e1e1;
      width: 140px;
      font-weight: 700;
      padding: 10px;
    }
  }
}
</style>