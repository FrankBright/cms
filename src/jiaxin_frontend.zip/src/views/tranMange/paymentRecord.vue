<template>
  <div class="paymentRecord">
    <h3 class="page-title">打款记录</h3>
    <!-- 过滤表单 start-->
    <XFilterComponent @submit="filterQuery" :formData="filterData" :rules="rules" btnToTop>
      <!-- 下单时间 -->
      <el-form-item label="时间" prop="date" style="width:50%">
        <el-date-picker
          v-model="filterData.date"
          type="datetimerange"
          range-separator="至"
          :default-time="['00:00:00', '23:59:59']"
          value-format="yyyy-MM-dd HH:mm:ss"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item label="收款人" prop="receiver">
        <el-input v-model="filterData.receiver" placeholder="收款人"></el-input>
      </el-form-item>
      <el-form-item label="批次号" prop="batchNo">
        <el-input v-model="filterData.batchNo" placeholder="批次号"></el-input>
      </el-form-item>
      <XSelectCompoent
        label="订单状态"
        :clearable="true"
        name="status"
        url="/jiaxin-web/common/dataDic.do?dataTypeNo=1003"
        v-model="filterData.status"
      ></XSelectCompoent>
      <template slot="othertool">
        <a :href="downLink" target="_blank" class="download-btn"><i class="el-icon-download"></i>下载列表</a>
        <!-- <el-button icon="el-icon-download" @click="download">下载列表</el-button> -->
      </template>
    </XFilterComponent>
    <!-- 过滤表单 end-->
    <!-- 表格 start-->
    <XTableComponent ref="tableList" :url="queryListUrl" :filterData="filterData">
      <template slot="table">
        <el-table-column prop="createdTime" label="创建时间"></el-table-column>
        <el-table-column prop="batchNo" label="批次号"></el-table-column>
        <el-table-column prop="platformId" label="平台id"></el-table-column>
        <el-table-column prop="userName" label="姓名"></el-table-column>
        <el-table-column prop="userMobile" label="手机号"></el-table-column>
        <el-table-column prop="userIdCardNo" label="身份证号"></el-table-column>
        <el-table-column prop="userBankCardNo" label="银行账号"></el-table-column>
        <el-table-column prop="salaryAmount" label="打款金额(元)">
          <template slot-scope="scope">{{scope.row.salaryAmount&&scope.row.salaryAmount.toFixed(2)}}</template>
        </el-table-column>
        <el-table-column prop="orderNo" label="订单流水号"></el-table-column>
        <el-table-column prop="status.desc" label="订单状态"></el-table-column>
      </template>
    </XTableComponent>
    <!-- 表格 end-->
  </div>
</template>

<script>
import XFilterComponent from "@/components/FilterTable/XFilterComponent";
import XTableComponent from "@/components/FilterTable/XTableComponent";
import XSelectCompoent from "@/components/FilterTable/XSelectCompoent";
import qs from "qs";
export default {
  name: "example",
  components: {
    XFilterComponent, //过滤表单组件
    XTableComponent, //表格组件
    XSelectCompoent //下拉二次封装
  },
  data() {
    return {
      //-----------------列表查询模型必要配置start
      filterData: {
        //过滤条件数据，所有查询字段需实现定义
        date: [], //时间范围默认是前端控件是数组类型，不符合接口类型，需进行watch进行分别赋值，建议后端更改接口类型最为合适
        status: null,
        receiver: "",
        batchNo: ""
      },
      rules: {
        //过滤提交校验、非必填:样例如下
        // userName: [
        //   { required: true, message: "请输入用户名", trigger: "blur" },
        //   { min: 1, max: 7, message: "长度在 1 到 7 个字符", trigger: "blur" }
        // ]
      },
      queryListUrl: "/jiaxin-web/order/getOrders.do" //列表查询url
      // formatFilterData:null, 过滤数据不能直接使用，启用该方式
      //-----------------列表查询模型必要配置end
    };
  },
  created() {
    
  },
  mounted() {},
  methods: {
    filterQuery() {
      this.$refs["tableList"].resetQueryData(1, true);
    },
    // download() {
    //   let query = "";
    //   Object.entries(this.filterData).forEach(item => {
    //     query += `${item[0]}=${item[1]}&`;
    //   });
    //   window.open("/jiaxin-web/order/exportOrders.do?" + query);
    // }
  },
  computed: {
    downLink(){
      const query = qs.stringify(this.filterData);
      return "/jiaxin-web/order/exportOrders.do?" + query;
    }
  },
  watch: {}
};
</script>
<style lang="scss" scoped>
.paymentRecord {
  .download-btn{
    display: inline-block;
    line-height: 1;
    cursor: pointer;
    background: #FFF;
    border: 1px solid #DCDFE6;
    color: #606266;
    text-align: center;
    box-sizing: border-box;
    margin-left:10px;
    padding: 10px 20px;
    border-radius: 4px;
    vertical-align: baseline;
  }
}
</style>