<template>
  <div class="login">
    <div class="rbj"></div>
    <div class="l-c">
      <div class="login-container">
        <div class="login-logo">
          <img :src="logoPath">
        </div>
        <div class="login-form">
          <div class="login-form-content">
            <el-form autocomplete="on" :model="loginForm" :rules="loginRules" ref="loginForm">
              <el-form-item prop="username">
                <el-input
                  name="username"
                  type="text"
                  v-model="loginForm.username"
                  autocomplete="on"
                  placeholder="用户名"
                ></el-input>
              </el-form-item>
              <el-form-item prop="password">
                <el-input
                  :type="passwordType"
                  v-model="loginForm.password"
                  autocomplete="on"
                  placeholder="密码"
                ></el-input>
                <!-- <span class="show-pwd" @click="showPwd"></span> -->
              </el-form-item>
              <el-form-item prop="imageVerCode">
                <el-input
                  @keyup.native.13="handleLogin"
                  v-model="loginForm.imageVerCode"
                  placeholder="验证码"
                  maxlength="4"
                ></el-input>
                <img :src="codeUrl" class="imageVerCode" @click="freshCode">
              </el-form-item>
              <el-form-item class="btn-ct">
                <el-button
                  type="primary"
                  class="login-btn"
                  :loading="loading"
                  @click.native.prevent="handleLogin"
                  style="width:100%;"
                >登录</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <div class="ft">联系我们，请邮件发送jiaxintang@ipaynow.cn</div>
    </div>
  </div>
</template>

<script>
import md5 from "js-md5";
import { setToken, getToken } from "@/utils/auth";
import { mapActions, mapGetters, mapMutations } from "vuex";
export default {
  components: {},
  name: "login",
  data() {
    return {
      logoPath: require("@/assets/images/login-logo.png"),
      codeUrl: null,
      loginForm: {
        username: "",
        password: "",
        imageVerCode: ""
      },
      loginRules: {
        username: [
          { required: true, trigger: "blur", message: "请输入正确的用户名" }
        ],
        password: [
          { required: true, trigger: "blur", message: "请输入正确的密码" }
        ],
        imageVerCode: [
          { required: true, trigger: "blur", message: "请输入正确的验证码" }
        ]
      },
      passwordType: "password",
      loading: false,
      redirect: null
    };
  },
  computed: {
    ...mapGetters(["token"])
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect;
      },
      immediate: true
    }
  },
  created() {
    this.freshCode();
  },
  methods: {
    ...mapActions(["FedLogOut"]),
    ...mapMutations(["SET_TOKEN", "SET_USERNAME", "SET_USERINFO"]),
    showPwd() {
      if (this.passwordType === "password") {
        this.passwordType = "";
      } else {
        this.passwordType = "password";
      }
    },
    freshCode() {
      this.codeUrl = "/jiaxin-web/login/getImgVerCode.do?" + Math.random();
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true;
          let password = md5(
            this.loginForm.username +
              this.loginForm.password.length +
              this.loginForm.password
          ).slice(-16);
          this.$http
            .post(
              "/jiaxin-web/login/merchantLogin.do",
              Object.assign({}, this.loginForm, {
                password
              })
            )
            .then(
              ({ data }) => {
                this.loading = false;
                this.SET_TOKEN(new Date());
                this.SET_USERINFO(JSON.stringify(data));
                this.SET_USERNAME(data.username);
                this.$router.push({ path: this.redirect || "/" });
              },
              err => {
                this.loading = false;
                this.freshCode();
              }
            );
        }
      });
    }
  },
  mounted() {
    this.token && this.FedLogOut();
  }
};
</script>


<style lang="scss">
.login {
  .el-form-item {
    border-bottom: #e2e2e2 1px solid;
    &.btn-ct {
      border-bottom: 0;
      margin-top: 70px;
    }
  }
  .el-input__inner {
    border: 0;
    padding-left: 0;
  }
  .el-button {
    padding: 12px 20px;
  }
  .el-form-item__error {
    top: 110%;
  }
}
</style>

<style lang="scss" scoped>
.login {
  background-color: #ebf4fa;
  height: 100%;
  width: 100%;
  position: relative;
  .rbj {
    position: absolute;
    right: 0;
    width: 50%;
    top: 0;
    background: #ebf4fa url(../../assets/images/login-bj.png) center center
      no-repeat;
    height: 100%;
  }
  .l-c {
    position: absolute;
    left: 0;
    width: 50%;
    top: 0;
    background: #fff;
    height: 100%;
    .ft {
      position: absolute;
      bottom: 30px;
      text-align: center;
      width: 100%;
      color: #969696;
    }
  }
  .login-container {
    background: #ffffff;
    border-radius: 4px;
    width: 320px;
    height: 400px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    .login-logo {
      margin-bottom: 45px;
    }
    .login-form {
      .imageVerCode {
        position: absolute;
        width: 100px;
        height: 35px;
        right: 0px;
        bottom: 5px;
      }
    }
  }
}
</style>

