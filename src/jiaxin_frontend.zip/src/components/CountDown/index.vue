<template>
  <div class="count-down">
    <slot name="initct" :time="formatTime" v-if="endTime&&time>0"></slot>
    <slot name="endct" :endTime="msgTime" v-if="time<1||!endTime"></slot>
  </div>
</template>
<script>
function formatTime(time) {
  let h = Math.floor(time / (1000 * 60 * 60));
  let m = Math.floor((time % (1000 * 60 * 60)) / (1000 * 60));
  let s = Math.floor(((time % (1000 * 60 * 60)) % (1000 * 60)) / 1000);
  return (
    (h > 9 ? h : "0" + h) +
    "：" +
    (m > 9 ? m : "0" + m) +
    "：" +
    (s > 9 ? s : "0" + s)
  );
}
export default {
  created() {},
  props: ["endTime", "remainingTime","msgTime"],
  data() {
    return {
      time: null
    };
  },
  computed: {
    formatTime() {
      return formatTime(this.time);
    }
  },
  methods: {
    init() {
      const endTime = new Date(this.endTime);
      const nowTime = new Date();
      if (endTime > nowTime) {
        this.time = endTime - nowTime;
        this.countDown();
      } else {
        this.time = 0;
      }
    },
    countDown() {
      this.time -= 1000;
      if (this.time > 0) {
        setTimeout(this.countDown, 1000);
      } else {
        this.time = 0;
      }
    }
  },
  created() {
    // this.endTime="2019-06-10 17:01:00"
    this.init();
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.count-down {
  display: inline-block;
}
</style>
