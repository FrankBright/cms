<template>
  <div id="wrapper">
    <Title :titles="titles" activeIndex="1"/>
    <dl class="des">
      <dt>批量打款文件说明：</dt>
      <dd>1. 打款文件最多支持10000条记录。</dd>
      <dd>2. 单笔金额最大支持金额为99000。</dd>
      <dd>
        3. 模版参照，
        <a href="/jiaxin-web/order/downloadTemplate.do" target="_blank">点击下载批量打款模版</a>
      </dd>
    </dl>
    <h4>请选择已填好的打款文件</h4>
    <div class="upload">
      <el-upload
        class="upload-demo"
        action="/jiaxin-web/order/upload.do"
        :show-file-list="false"
        :on-success="uploadSuc"
        :file-list="fileList3"
        :beforeUpload="beforeAvatarUpload"
        accept=".xlsx"
      >
        <el-button @click="upload">
          <i class="iconfont icon-unie123"></i>
          请选择上传文件
        </el-button>
        <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
      </el-upload>
      <i
        :class="{
                'iconfont':true, 
                'icon-tongguo':uploadStatus == 1,
                'icon-weitongguo':uploadStatus === 0
            }"
      ></i>
      <span v-if="uploadStatus == 1">校验通过</span>
      <span v-else-if="uploadStatus === 0">
        校验未通过
        <a :href="`/jiaxin-web/order/download.do?fileId=${checkFileId}`" target="_blank" style='margin-left: 15px;'>校验结果文件</a>
      </span>
    </div>
    <el-button
      type="primary"
      size="medium"
      :disabled="uploadStatus != 1 || checkStatus"
      :loading="checkStatus"
      @click="onNext"
    >{{checkStatus ? '处理中' : '下一步'}}</el-button>
  </div>
</template>

<script>
import Title from "@/components/title.vue";
export default {
  data() {
    return {
      titles: ["上传打款文件", "核对打款信息", "开始打款"],
      uploadStatus: "",
      timer: null,
      checkStatus: false,
      fileId: "",
      checkFileId: "",
      password: ""
    };
  },
  components: { Title },
  methods: {
    beforeAvatarUpload(file) {
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const extension = testmsg === "xlsx";
      if (!extension) {
        this.$message({
          message: "上传文件只能是xlsx格式!",
          type: "warning"
        });
      }
      return extension;
    },
    uploadSuc(res, file, fileList) {
      console.log(res);
      //文件上传成功
      if (res.code == 0) {
        this.uploadStatus = res.data.status; //校验状态
        this.fileId = res.data.fileId; //文件id
        this.checkFileId = res.data.checkFileId; //文件id
      } else {
        this.$message({
          type: "error",
          message: res.msg
        });
      }
    },
    queryStatus(token) {
      this.checkStatus = true;
      this.$http
        .get("/jiaxin-web/order/batchProcessStatus.do", {
          token
        })
        .then(res => {
          if (res.data.status.code == 1) {
            this.$router.push({
              path: "/batch/checkPayment",
              query: {
                batchNo: res.data.batchNo
              }
            });
          } else {
            this.timer = setTimeout(this.queryStatus.bind(this, token), 5000);
          }
        });
    },
    onNext() {
      this.$http
        .post("/jiaxin-web/order/batchSumitApply.do", {
          fileId: this.fileId
        })
        .then(
          res => {
            if (res.code == 0) {
              this.queryStatus(res.data.token);
            } else {
              this.$message({
                type: "error",
                message: res.msg
              });
            }
          },
          message => {
            this.$message({
              type: "error",
              message
            });
          }
        );
    }
  },
  mounted() {}
};
</script>

<style lang="scss" scoped>
#wrapper {
  .des {
    background: #fffdf5;
    border: 1px solid #ffc836;
    border-radius: 4px;
    padding: 20px;
    margin-bottom: 40px;
    dt {
      line-height: 20px;
      font-size: 14px;
      margin-bottom: 6px;
      color: #333;
    }
    dd {
      line-height: 17px;
      color: #666;
      font-size: 12px;
      margin-bottom: 6px;
      margin-left: 0;
    }
  }
  h4 {
    font-size: 16px;
    color: #333333;
    font-weight: normal;
  }
  .upload {
    margin-top: 44px;
    margin-bottom: 86px;
    .upload-demo {
      display: inline-block;
      margin-right: 20px;
    }
    i {
      vertical-align: middle;
      margin-right: 10px;
      font-size: 18px;
    }
    .icon-tongguo {
      color: #67c23a;
    }
    .icon-weitongguo {
      color: #fa5555;
      vertical-align: -1px;
    }
    span {
      font-size: 12px;
      color: #333;
    }
  }
}
.rechargeInfo {
  line-height: 32px;
  p {
    color: #646464;
  }
  .m {
    margin: 10px 0;
  }
  hr {
    margin-top: 6px;
  }
  .info {
    background-color: #f8f8f8;
    padding: 10px 20px;
  }
  .flex {
    margin-top: 10px;
    display: flex;
    label {
      display: inline-block;
      width: 100px;
      line-height: 32px;
    }
  }
}
a {
  color: #13a2c0;
  text-decoration: underline;
}
</style>
